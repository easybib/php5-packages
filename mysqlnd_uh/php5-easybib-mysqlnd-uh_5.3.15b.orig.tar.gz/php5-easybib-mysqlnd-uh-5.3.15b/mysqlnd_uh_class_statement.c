/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Authors: David Soria Parra <david.soria_parra@mayflower.de>          |
  |          Ulf Wendel <ulf.wendel@phpdoc.de>                           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "mysqlnd_uh_hooks.h"
#include "mysqlnd_uh_classes.h"
#include "php_mysqlnd_uh.h"

#define PARSE_METHOD_SINGLE_PARAM_STMT(zv_rsrc, stmt) \
	CHECK_ENABLED(); \
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &zv_rsrc) == FAILURE) { \
		RETURN_NULL(); \
	} \
	ZEND_FETCH_RESOURCE(stmt, MYSQLND_STMT*, &zv_rsrc, -1, MYSQLND_UH_RES_MYSQLND_STMT_NAME, le_mysqlnd_uh_mysqlnd_stmt);

#define CLASS_STMT_PHP_METHOD_ONE_ARG_STMT_RET_BOOL(mysqlnd_method_name, userland_method_name, true_value, stmt_cast) \
	PHP_METHOD(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, userland_method_name) \
	{ \
		zval* mysqlnd_stmt_rsrc; \
		MYSQLND_STMT *stmt; \
		\
		PARSE_METHOD_SINGLE_PARAM_STMT(mysqlnd_stmt_rsrc, stmt); \
		\
		if (true_value == org_mysqlnd_stmt_methods.mysqlnd_method_name((stmt_cast)stmt TSRMLS_CC)) { \
			RETVAL_TRUE; \
		} else { \
			RETVAL_FALSE; \
		} \
	}

/* resources */
zend_class_entry *php_mysqlnd_uh_class_prepared_statement_entry;


/* mysqlnd plugin related */

/* typedef enum_func_status	(*func_mysqlnd_stmt__prepare)(MYSQLND_STMT * const stmt,
const char * const query, unsigned int query_len TSRMLS_DC); */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, prepare)
{
	MYSQLND_STMT *stmt;
	zval* mysqlnd_stmt_rsrc;
	char *query;
	int query_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_stmt_rsrc, &query, &query_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(stmt, MYSQLND_STMT*, &mysqlnd_stmt_rsrc, -1, MYSQLND_UH_RES_MYSQLND_STMT_NAME, le_mysqlnd_uh_mysqlnd_stmt);

	if (PASS == org_mysqlnd_stmt_methods.prepare(stmt, query, query_len TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* typedef enum_func_status	(*func_mysqlnd_stmt__execute)(MYSQLND_STMT * const stmt TSRMLS_DC); */
CLASS_STMT_PHP_METHOD_ONE_ARG_STMT_RET_BOOL(execute, execute, PASS, MYSQLND_STMT * const)


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, __construct)
{
	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED);
		RETURN_FALSE;
	}
}
/* }}} */


/* mysqlnd prepared statement class */
struct st_mysqlnd_stmt_methods org_mysqlnd_stmt_methods;

/* PHP Infrastructure */

#define METHOD_ARG_INFO_BEGIN_W_STMT(method) \
	ZEND_BEGIN_ARG_INFO(method, 0) \
		ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_STMT_NAME)

#define METHOD_ARG_INFO_END() \
	ZEND_END_ARG_INFO()

#define METHOD_ARG_INFO_STMT_ONLY_ARG(name) \
	METHOD_ARG_INFO_BEGIN_W_STMT(name) \
	METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_STMT(prepare_arginfo)
	ZEND_ARG_INFO(0, "query")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_STMT_ONLY_ARG(execute_arginfo)

static zend_function_entry php_mysqlnd_uh_class_prepared_statement_functions[] = {
	PHP_ME(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, execute, execute_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, prepare, prepare_arginfo, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

/* {{{ */
void mysqlnd_uh_minit_register_class_statement(TSRMLS_D)
{
	/* register the classes defined by the extension during MINIT */
	zend_class_entry ce_pstmt;

	INIT_CLASS_ENTRY(ce_pstmt, MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME, php_mysqlnd_uh_class_prepared_statement_functions);
	php_mysqlnd_uh_class_prepared_statement_entry = zend_register_internal_class(&ce_pstmt TSRMLS_CC);
}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
