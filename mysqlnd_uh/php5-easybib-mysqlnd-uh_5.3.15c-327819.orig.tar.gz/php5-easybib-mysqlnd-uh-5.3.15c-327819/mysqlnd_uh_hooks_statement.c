/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Authors: David Soria Parra <david.soria_parra@mayflower.de>          |
  |          Ulf Wendel <ulf.wendel@phpdoc.de>                           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_mysqlnd_uh.h"
#include "mysqlnd_uh_classes.h"
#include "mysqlnd_uh_hooks.h"

#define RETVAL_CHECK_TYPE(retval, method_name, expect_type, type_name) \
	MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, expect_type, type_name, MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME)

#define RETVAL_BOOL_CHECK_TYPE(retval, method_name) \
	MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, IS_BOOL, "boolean", MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME)

#define RETVAL_STRING_CHECK_TYPE(retval, method_name) \
	MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, IS_STRING, "string", MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME)

#define RETVAL_NUMBER_CHECK_TYPE(retval, method_name, type_name) \
	MYSQLND_UH_HOOK_RETVAL_NUMBER_CHECK_TYPE(retval, method_name, type_name, MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME)

#define RETVAL_BOOL_TO_FUNC_STATUS(retval, ret) \
	MYSQLND_UH_HOOK_RETVAL_BOOL_TO_FUNC_STATUS(retval, ret)

#define RETVAL_INTERNAL_RESOURCE(retval, resource, resource_type, resource_name, le_resource, bail_if_no_resource) \
	MYSQLND_UH_HOOK_RETVAL_INTERNAL_RESOURCE(retval, resource, resource_type, resource_name, le_resource, bail_if_no_resource, MYSQLND_UH_CLASS_CONNECTION_NAME)

#define EXTRACT_DATA_AND_USER_OBJ(mysqlnd_stmt, plugin_data, user_hook_obj) \
	MYSQLND_UH_STMT_DATA **plugin_data; \
	zval *user_hook_obj = NULL; \
	plugin_data = (MYSQLND_UH_STMT_DATA **) mysqlnd_uh_get_plugin_statement_data((const MYSQLND_STMT*)mysqlnd_stmt, TRUE TSRMLS_CC); \
	if (plugin_data) \
		user_hook_obj = (*plugin_data && (*plugin_data)->user_obj) ? (*plugin_data)->user_obj : MYSQLND_UH_G(stmt_user_obj);

#define MYSQLND_STMT_METHOD_ONE_ARG_STMT_RET_FUNC_STATUS(mysqlnd_method_name, userland_method_name, userland_method_name_cc, stmt_arg_decl) \
	MYSQLND_UH_HOOK_METHOD_ONE_ARG_RES_RET_FUNC_STATUS(org_mysqlnd_stmt_methods, mysqlnd_uh_stmt, mysqlnd_method_name, userland_method_name, userland_method_name_cc, stmt, stmt_arg_decl)


/* mysqli zend class handler */
/* TODO: fix path */
#include "mysqli_comp_structs.h"

/*
	mysqlnd function tables for connections. See below how to
	set and modify them to make them call your mysqlnd hooks.

	(You would probably declare both of them static, however,
	I need one of them in mysqlnd_uh_classes.c)
*/
static struct st_mysqlnd_stmt_methods *my_mysqlnd_stmt_methods;

/* {{{ */
enum_func_status MYSQLND_METHOD(mysqlnd_uh_stmt, prepare)(MYSQLND_STMT * const stmt, const char * const query, unsigned int query_len TSRMLS_DC) {
	enum_func_status ret = FAIL;

	DBG_ENTER("mysqlnd_uh_stmt.prepare");
	DBG_INF_FMT("statement %p", stmt);

	EXTRACT_DATA_AND_USER_OBJ(stmt, stmt_data, stmt_obj);

	if (stmt_obj) {
		MYSQLND_UH_HOOK_ARG_RESOURCE(stmt_resource, stmt_data);
		MYSQLND_UH_HOOK_ARG_STRING_LEN(query, query_len);

		zval *retval = NULL;
		mysqlnd_uh_call_method_with_2_params(stmt_obj, NULL, "prepare", &retval, stmt_resource, zv_query);
		zval_ptr_dtor(&zv_query);

		RETVAL_BOOL_CHECK_TYPE(retval, "prepare");
		RETVAL_BOOL_TO_FUNC_STATUS(retval, ret);

	} else {
		ret = org_mysqlnd_stmt_methods.prepare(stmt, query, query_len TSRMLS_CC);
	}

	DBG_RETURN(ret);
}
/* }}} */

MYSQLND_STMT_METHOD_ONE_ARG_STMT_RET_FUNC_STATUS(execute, execute, execute, MYSQLND_STMT * const stmt)

/* {{{ */
void MYSQLND_METHOD(mysqlnd_uh_stmt, free_stmt_content)(MYSQLND_STMT * const stmt TSRMLS_DC) {

	DBG_ENTER("mysqlnd_uh_stmt.free_stmt_content");
	DBG_INF_FMT("statement %p", stmt);

	mysqlnd_uh_conn_free_plugin_statement_data(stmt, FALSE TSRMLS_CC);

	org_mysqlnd_stmt_methods.free_stmt_content(stmt TSRMLS_CC);

	DBG_VOID_RETURN;
}
/* }}} */

/* {{{ */
enum_func_status MYSQLND_METHOD(mysqlnd_uh_stmt, dtor)(MYSQLND_STMT * const stmt, zend_bool implicit TSRMLS_DC) {
	enum_func_status ret = FAIL;

	DBG_ENTER("mysqlnd_uh_stmt.dtor");
	DBG_INF_FMT("statement %p", stmt);

	mysqlnd_uh_conn_free_plugin_statement_data(stmt, FALSE TSRMLS_CC);
	ret = org_mysqlnd_stmt_methods.dtor(stmt, implicit TSRMLS_CC);

	DBG_RETURN(ret);
}
/* }}} */

/* {{{ */
/*
	Registration of a mysqlnd plugin and setting hooks:
		a) obtain unique plugin id (php_mysqlnd_uh.c)
		b) get mysqlnd function lookup table for connection, statement,
		   resultset, protocol or net stuff (mysqlnd_uh_hooks_*.c)
		c) copy, modify and install new function lookup table (mysqlnd_uh_hooks_*.c)
*/
void mysqlnd_uh_minit_register_hooks_statement(TSRMLS_D)
{
	/* Get pointer to prepared statement methods */
	my_mysqlnd_stmt_methods = mysqlnd_stmt_get_methods();

	/* Backup originial function pointers in org_mysqlnd_stmt_methods */
	memcpy(&org_mysqlnd_stmt_methods, my_mysqlnd_stmt_methods, sizeof(struct st_mysqlnd_stmt_methods));

	/* Replace selected methods */
	my_mysqlnd_stmt_methods->execute						= MYSQLND_METHOD(mysqlnd_uh_stmt, execute);
	my_mysqlnd_stmt_methods->prepare						= MYSQLND_METHOD(mysqlnd_uh_stmt, prepare);
	my_mysqlnd_stmt_methods->dtor							= MYSQLND_METHOD(mysqlnd_uh_stmt, dtor);
	my_mysqlnd_stmt_methods->free_stmt_content				= MYSQLND_METHOD(mysqlnd_uh_stmt, free_stmt_content);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
