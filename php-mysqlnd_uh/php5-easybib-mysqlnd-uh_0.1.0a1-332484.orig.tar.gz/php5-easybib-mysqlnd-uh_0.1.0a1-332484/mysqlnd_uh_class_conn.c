/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "mysqlnd_uh_hooks.h"
#include "mysqlnd_uh_classes.h"
#include "php_mysqlnd_uh.h"

/* resources */
zend_class_entry *php_mysqlnd_uh_class_conn_entry;

/* mysqlnd plugin related */

/* mysqlnd connection class */
struct st_mysqlnd_conn_methods org_mysqlnd_conn_methods;


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_NAME, connect)
{
	const char *host = NULL, *user = NULL, *passwd = NULL, *db = NULL, *mysql_socket = NULL;
	int host_len = 0, user_len = 0, passwd_len = 0, db_len = 0, socket_len = 0;
	long port = 0, mysql_flags = 0;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND *conn;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs!sssls!l", &mysqlnd_rsrc,
		&host, &host_len, &user, &user_len, &passwd, &passwd_len,
		&db, &db_len, &port, &mysql_socket, &socket_len, &mysql_flags) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_NAME, le_mysqlnd_uh_mysqlnd_conn);
	conn = res_conn->mysqlnd_conn;

	if (PASS == org_mysqlnd_conn_methods.connect(
		conn, host, user, passwd, passwd_len, db, db_len,
		port, mysql_socket, mysql_flags TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_NAME, close)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND *conn;
	long close_type;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &close_type) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_NAME, le_mysqlnd_uh_mysqlnd_conn);
	conn = res_conn->mysqlnd_conn;

	if (PASS == org_mysqlnd_conn_methods.close((MYSQLND *)conn, (enum_connection_close_type)close_type TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_NAME, __construct)
{
	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED);
		RETURN_FALSE;
	}
}
/* }}} */

/* Additional argument info for Zend - may it be used for helpful dev tips... */
#define METHOD_ARG_INFO_BEGIN_W_CONN(method) \
	ZEND_BEGIN_ARG_INFO(method, 0) \
		ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_CONN_NAME)

#define METHOD_ARG_INFO_END() \
	ZEND_END_ARG_INFO()

METHOD_ARG_INFO_BEGIN_W_CONN(connect_arginfo)
	ZEND_ARG_INFO(0, "host")
	ZEND_ARG_INFO(0, "user")
	ZEND_ARG_INFO(0, "password")
	ZEND_ARG_INFO(0, "database")
	ZEND_ARG_INFO(0, "port")
	ZEND_ARG_INFO(0, "socket")
	ZEND_ARG_INFO(0, "mysql_flags")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(close_arginfo)
	ZEND_ARG_INFO(0, "close_type")
METHOD_ARG_INFO_END()

static zend_function_entry php_mysqlnd_uh_class_connection_functions[] = {
	PHP_ME(MYSQLND_UH_CLASS_CONN_NAME, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(MYSQLND_UH_CLASS_CONN_NAME, connect, connect_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_NAME, close, close_arginfo, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

/* {{{ */
void mysqlnd_uh_minit_register_class_conn(TSRMLS_D)
{
	/* register the classes defined by the extension during MINIT */
	zend_class_entry ce_conn;

	INIT_CLASS_ENTRY(ce_conn, MYSQLND_UH_CLASS_CONN_NAME, php_mysqlnd_uh_class_connection_functions);
	php_mysqlnd_uh_class_conn_entry = zend_register_internal_class(&ce_conn TSRMLS_CC);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
