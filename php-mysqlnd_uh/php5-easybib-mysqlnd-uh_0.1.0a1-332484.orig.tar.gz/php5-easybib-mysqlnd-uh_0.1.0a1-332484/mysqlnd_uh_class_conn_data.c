/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "mysqlnd_uh_hooks.h"
#include "mysqlnd_uh_classes.h"
#include "php_mysqlnd_uh.h"

#define PARSE_METHOD_SINGLE_PARAM_CONN(zv_rsrc, conn_data, res_conn) \
	CHECK_ENABLED(); \
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &zv_rsrc) == FAILURE) { \
		RETURN_NULL(); \
	} \
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &zv_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data); \
	conn_data = res_conn->mysqlnd_conn_data;

	/* Its getting boring and becoming cut & paste - lets use the preprocessor */
#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(mysqlnd_method_name, userland_method_name, true_value, conn_cast) \
	PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, userland_method_name) \
	{ \
		zval* mysqlnd_rsrc; \
		MYSQLND_UH_RES_CONN* res_conn; \
		MYSQLND_CONN_DATA *conn_data; \
		\
		PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn); \
		\
		if (true_value == org_mysqlnd_conn_data_methods.mysqlnd_method_name((conn_cast)conn_data TSRMLS_CC)) { \
			RETVAL_TRUE; \
		} else { \
			RETVAL_FALSE; \
		} \
	}

#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_LONG(mysqlnd_method_name, userland_method_name, conn_cast) \
	PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, userland_method_name) \
	{ \
		zval* mysqlnd_rsrc; \
		MYSQLND_UH_RES_CONN* res_conn; \
		MYSQLND_CONN_DATA *conn_data; \
		\
		PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn); \
		\
		RETVAL_LONG((long)org_mysqlnd_conn_data_methods.mysqlnd_method_name((conn_cast)conn_data TSRMLS_CC)); \
	}

/* TODO - check if we can do some sort of range checking here */
#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(mysqlnd_method_name, userland_method_name, conn_cast) \
	CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_LONG(mysqlnd_method_name, userland_method_name, conn_cast)

#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT64(mysqlnd_method_name, userland_method_name, conn_cast) \
	CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_LONG(mysqlnd_method_name, userland_method_name, conn_cast)

#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_ULONG(mysqlnd_method_name, userland_method_name, conn_cast) \
	CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_LONG(mysqlnd_method_name, userland_method_name, conn_cast)

#define CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(mysqlnd_method_name, userland_method_name, conn_cast) \
	PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, userland_method_name) \
	{ \
		zval* mysqlnd_rsrc; \
		MYSQLND_CONN_DATA *conn_data; \
		MYSQLND_UH_RES_CONN* res_conn; \
		const char * tmp; \
		\
		PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn); \
		\
		tmp = org_mysqlnd_conn_data_methods.mysqlnd_method_name((conn_cast)conn_data TSRMLS_CC); \
		if (tmp) { \
			RETVAL_STRING(tmp, 1); \
		} else if (NULL != tmp) { \
			RETVAL_STRING("", 1); \
		} else { \
		    /* TODO: NULL vs. \0 difference hidden from the user */ \
		    RETVAL_STRING("", 1); \
		} \
	}

/* resources */
zend_class_entry *php_mysqlnd_uh_class_conn_data_entry;

/* mysqlnd plugin related */

/* mysqlnd connection class */
struct st_mysqlnd_conn_data_methods org_mysqlnd_conn_data_methods;

/* {{{ */
/*
	Our default implementation for Mysqlnd User Handler::query().
	It actually looks pretty stupid because it does nothing but
	call the original mysqlnd function handler in a super complicated
	way and exposing the internal mysqlnd connection to user land
	which is kind of a no go. However, its been the easiest way
	I could think of to allow users to write pre- and post hooks
	like this:

	class my_proxy MysqlndUhConnection {
	  function query($res, $query) {
	     print "pre hook goes here\n";
		 $ret = parent::query($res, $query);
		 print "post hook goes here\n";
		 return $ret;
	  }
	}
*/
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, query)
{
	char *query_string;
	unsigned int query_string_len;
	zval *mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED);
		RETURN_FALSE;
	}

	/* its ugly to tunnel the mysqlnd connection through the user land but we need it for calling the original mysqlnd functions */
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &query_string, &query_string_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.query(conn_data, query_string, query_string_len TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, init)
{
	zval *mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn);
	org_mysqlnd_conn_data_methods.init(conn_data TSRMLS_CC);

	/* not needed by mysqlnd - userland only and not used */
	RETURN_TRUE;
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, connect)
{
	const char *host = NULL, *user = NULL, *passwd = NULL, *db = NULL, *mysql_socket = NULL;
	int host_len = 0, user_len = 0, passwd_len = 0, db_len = 0, socket_len = 0;
	long port = 0, mysql_flags = 0;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs!sssls!l", &mysqlnd_rsrc,
		&host, &host_len, &user, &user_len, &passwd, &passwd_len,
		&db, &db_len, &port, &mysql_socket, &socket_len, &mysql_flags) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.connect(
		conn_data, host, user, passwd, passwd_len, db, db_len,
		port, mysql_socket, mysql_flags TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, escapeString)
{
	char *escapestr, *newstr;
	int escapestr_len;
	ulong newstr_len;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &escapestr, &escapestr_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	newstr = safe_emalloc(2, escapestr_len, 1);
	newstr_len = org_mysqlnd_conn_data_methods.escape_string(conn_data, newstr, escapestr, escapestr_len TSRMLS_CC);
	newstr = erealloc(newstr, newstr_len + 1);

	RETURN_STRINGL(newstr, newstr_len, 0);
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, setCharset)
{
	char *charset;
	int charset_len;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &charset, &charset_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.set_charset(conn_data, charset TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, sendQuery)
{
	char *query;
	int query_len;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &query, &query_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.send_query(conn_data, query, query_len TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(reap_query, reapQuery, PASS, MYSQLND_CONN_DATA *)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, useResult)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_RES *res;

	PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn);

	res = org_mysqlnd_conn_data_methods.use_result(conn_data TSRMLS_CC);
	ZEND_REGISTER_RESOURCE(return_value, (void *)res, le_mysqlnd_uh_mysqlnd_res);
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, storeResult)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_RES *res;

	PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn);

	res = org_mysqlnd_conn_data_methods.store_result(conn_data TSRMLS_CC);
	ZEND_REGISTER_RESOURCE(return_value, (void *)res, le_mysqlnd_uh_mysqlnd_res);
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(next_result, nextResult, PASS, MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(more_results, moreResults, TRUE, const MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, stmtInit)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_STMT *res;

	PARSE_METHOD_SINGLE_PARAM_CONN(mysqlnd_rsrc, conn_data, res_conn);

	res = org_mysqlnd_conn_data_methods.stmt_init(conn_data TSRMLS_CC);
	ZEND_REGISTER_RESOURCE(return_value, (void *)res, le_mysqlnd_uh_mysqlnd_stmt);
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, shutdownServer)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long level;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &level) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (TRUE == org_mysqlnd_conn_data_methods.shutdown_server(conn_data, level TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, refreshServer)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long options;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &options) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (TRUE == org_mysqlnd_conn_data_methods.refresh_server(conn_data, (uint8_t)options TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(ping, ping, PASS, MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, killConnection)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long pid;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &pid) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.kill_connection(conn_data, (unsigned int)pid TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, selectDb)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	char *db;
	unsigned int db_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &db, &db_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.select_db(conn_data, db, db_len TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(server_dump_debug_information, serverDumpDebugInformation, PASS, MYSQLND_CONN_DATA * const)


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, changeUser)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	char *user, *passwd, *db;
	unsigned int user_len, passwd_len, db_len;
	zend_bool silent;
	long mysqlnd_passwd_len;

	CHECK_ENABLED();

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rsssbl", &mysqlnd_rsrc, &user, &user_len, &passwd, &passwd_len, &db, &db_len, &silent, &mysqlnd_passwd_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.change_user(conn_data, user, passwd, db, silent, (size_t)mysqlnd_passwd_len TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(get_error_no, getErrorNumber, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(get_error_str, getErrorString, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(get_sqlstate, getSqlstate, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT64(get_thread_id, getThreadId, const MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, getStatistics)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &mysqlnd_rsrc) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	org_mysqlnd_conn_data_methods.get_statistics(conn_data, return_value TSRMLS_CC ZEND_FILE_LINE_CC);
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_ULONG(get_server_version, getServerVersion, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(get_server_information, getServerInformation, const MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, getServerStatistics)
{
	char * server_stat = NULL;
	unsigned int stat_len = 0;
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &mysqlnd_rsrc) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	org_mysqlnd_conn_data_methods.get_server_statistics(conn_data, &server_stat, &stat_len TSRMLS_CC);
	RETURN_STRINGL(server_stat, stat_len, 0);
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(get_host_information, getHostInformation, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(get_protocol_information, getProtocolInformation, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(get_last_message, getLastMessage, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_STR(charset_name, charsetName, const MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, listFields)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_RES *res;
	char *table, *achtung_wild;
	unsigned int table_len, achtung_wild_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rss", &mysqlnd_rsrc, &table, &table_len, &achtung_wild, &achtung_wild_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	res = org_mysqlnd_conn_data_methods.list_fields(conn_data, table, achtung_wild TSRMLS_CC);
	ZEND_REGISTER_RESOURCE(return_value, (void *)res, le_mysqlnd_uh_mysqlnd_res);
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, listMethod)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_RES *res;
	char *query, *achtung_wild, *par1;
	unsigned int query_len, achtung_wild_len, par1_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rsss", &mysqlnd_rsrc, &query, &query_len, &achtung_wild, &achtung_wild_len, &par1, &par1_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	res = org_mysqlnd_conn_data_methods.list_method(conn_data, query, achtung_wild, par1 TSRMLS_CC);
	ZEND_REGISTER_RESOURCE(return_value, (void *)res, le_mysqlnd_uh_mysqlnd_res);
}
/* }}} */


CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT64(get_last_insert_id, getLastInsertId, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT64(get_affected_rows, getAffectedRows, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(get_warning_count, getWarningCount, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(get_field_count, getFieldCount, const MYSQLND_CONN_DATA * const)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_UINT(get_server_status, getServerStatus, const MYSQLND_CONN_DATA * const)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, setServerOption)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long option;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &option) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.set_server_option(conn_data, option TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, setClientOption)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long option;
	zval* zv_value;
	char *value = NULL;
	enum_func_status ret;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rlz", &mysqlnd_rsrc, &option, &zv_value) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	switch (Z_TYPE_P(zv_value)) {
		case IS_STRING:
			value = Z_STRVAL_P(zv_value);
			ret = org_mysqlnd_conn_data_methods.set_client_option(conn_data, option, value TSRMLS_CC);
			break;

		case IS_LONG:
			value = ecalloc(1, 256);
			snprintf(value, 256, "%ld", Z_LVAL_P(zv_value));
			ret = org_mysqlnd_conn_data_methods.set_client_option(conn_data, option, value TSRMLS_CC);
			efree(value);
			break;

		case IS_BOOL:
			value = (Z_BVAL_P(zv_value)) ? "1" : "0";
			ret = org_mysqlnd_conn_data_methods.set_client_option(conn_data, option, value TSRMLS_CC);
			break;

		case IS_NULL:
			value = NULL;
			ret = org_mysqlnd_conn_data_methods.set_client_option(conn_data, option, value TSRMLS_CC);
			break;

		default:
			php_error_docref(NULL TSRMLS_CC, E_ERROR, MYSQLND_UH_ERROR_PREFIX " Option value must by of type integer, double, string, boolean or be NULL ");
			ret = FAIL;
			break;
	}

	if (PASS == ret) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, queryReadResultsetHeader)
{
	zval* mysqlnd_rsrc;
	zval* zv_stmt;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	MYSQLND_STMT *stmt;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rz", &mysqlnd_rsrc, &zv_stmt) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (Z_TYPE_P(zv_stmt) == IS_RESOURCE) {
		ZEND_FETCH_RESOURCE(stmt, MYSQLND_STMT*, &zv_stmt, -1, MYSQLND_UH_RES_MYSQLND_STMT_NAME, le_mysqlnd_uh_mysqlnd_stmt);
	} else if (Z_TYPE_P(zv_stmt) == IS_NULL) {
		stmt = NULL;
	} else {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " The second parameter must be either a resource of type " MYSQLND_UH_RES_MYSQLND_STMT_NAME " or NULL");
		RETURN_NULL();
	}

	if (PASS == org_mysqlnd_conn_data_methods.query_read_result_set_header(conn_data, stmt TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, simpleCommand)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	char * arg;
	int arg_len = 0;
	long command, ok_packet;
	zend_bool silent, ignore_upsert_status;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rlslbb", &mysqlnd_rsrc, &command, &arg, &arg_len, &ok_packet, &silent, &ignore_upsert_status) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.simple_command(conn_data, command,
		arg, arg_len, ok_packet, silent, ignore_upsert_status TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, simpleCommandHandleResponse)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long command, ok_packet;
	zend_bool silent, ignore_upsert_status;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rlblb", &mysqlnd_rsrc,  &ok_packet, &silent, &command, &ignore_upsert_status) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.simple_command_handle_response(conn_data, ok_packet, silent, command, ignore_upsert_status TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(restart_psession, restartPSession, PASS, MYSQLND_CONN_DATA *)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(end_psession, endPSession, PASS, MYSQLND_CONN_DATA *)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(send_close, sendClose, PASS, MYSQLND_CONN_DATA *)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, sslSet)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	const char *key, *cert, *ca, *capath, *cipher;
	unsigned int key_len, cert_len, ca_len, capath_len, cipher_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rsssss", &mysqlnd_rsrc,  &key, &key_len,
		&cert, &cert_len, &ca, &ca_len, &capath, &capath_len, &cipher, &cipher_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.ssl_set(conn_data, key, cert, ca, capath, cipher TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, setAutocommit)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long mode;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &mode) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.set_autocommit(conn_data, (unsigned int)mode TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(tx_commit, txCommit, PASS, MYSQLND_CONN_DATA *)
CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(tx_rollback, txRollback, PASS, MYSQLND_CONN_DATA *)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, txBegin)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long mode;
	const char *name;
	unsigned int name_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rls", &mysqlnd_rsrc, &mode, &name, &name_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.tx_begin(conn_data, (const unsigned int)mode, (const char* const)name TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, txCommitOrRollback)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long mode;
	const char *name;
	unsigned int name_len;
	zend_bool commit;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rbls", &mysqlnd_rsrc, &commit, &mode, &name, &name_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.tx_commit_or_rollback(conn_data, (const zend_bool)commit, (const unsigned int)mode, (const char* const)name TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, txSavepoint)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	const char *name;
	unsigned int name_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &name, &name_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.tx_savepoint(conn_data, (const char* const)name TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, txSavepointRelease)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	const char *name;
	unsigned int name_len;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &mysqlnd_rsrc, &name, &name_len) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	if (PASS == org_mysqlnd_conn_data_methods.tx_savepoint_release(conn_data, (const char* const)name TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */

CLASS_CONN_PHP_METHOD_ONE_ARG_CONN_RET_BOOL(execute_init_commands, executeInitCommands, PASS, MYSQLND_CONN_DATA *)

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, __construct)
{
	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED);
		RETURN_FALSE;
	}
}
/* }}} */


/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_CONN_DATA_NAME, getUpdatedConnectFlags)
{
	zval* mysqlnd_rsrc;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND_CONN_DATA *conn_data;
	long mysql_flags;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &mysqlnd_rsrc, &mysql_flags) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(res_conn, MYSQLND_UH_RES_CONN*, &mysqlnd_rsrc, -1, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME, le_mysqlnd_uh_mysqlnd_conn_data);
	conn_data = res_conn->mysqlnd_conn_data;

	RETURN_LONG(org_mysqlnd_conn_data_methods.get_updated_connect_flags(conn_data, (const unsigned int)mysql_flags TSRMLS_CC));
}
/* }}} */


/* Additional argument info for Zend - may it be used for helpful dev tips... */
ZEND_BEGIN_ARG_INFO(query_arginfo, 0)
	ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME)
	ZEND_ARG_INFO(0, "query_string")
ZEND_END_ARG_INFO()

/* Well, you got the idea, let's use some preprocessor magic */
#define METHOD_ARG_INFO_BEGIN_W_CONN(method) \
	ZEND_BEGIN_ARG_INFO(method, 0) \
		ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME)

#define METHOD_ARG_INFO_END() \
	ZEND_END_ARG_INFO()

#define METHOD_ARG_INFO_CONN_ONLY_ARG(name) \
	METHOD_ARG_INFO_BEGIN_W_CONN(name) \
	METHOD_ARG_INFO_END()

#define METHOD_ARG_INFO_CONN_TWO_ARGS(name, by_ref_arg2, name_arg2) \
	METHOD_ARG_INFO_BEGIN_W_CONN(name) \
		ZEND_ARG_INFO(by_ref_arg2, name_arg2) \
	METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(init_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(connect_arginfo)
	ZEND_ARG_INFO(0, "host")
	ZEND_ARG_INFO(0, "user")
	ZEND_ARG_INFO(0, "password")
	ZEND_ARG_INFO(0, "database")
	ZEND_ARG_INFO(0, "port")
	ZEND_ARG_INFO(0, "socket")
	ZEND_ARG_INFO(0, "mysql_flags")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_TWO_ARGS(escapeString_arginfo, 0, "escape_string")
METHOD_ARG_INFO_CONN_TWO_ARGS(setCharset_arginfo, 0, "charset")
METHOD_ARG_INFO_CONN_TWO_ARGS(sendQuery_arginfo, 0, "query")
METHOD_ARG_INFO_CONN_ONLY_ARG(reapQuery_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(useResult_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(storeResult_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(nextResult_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(moreResults_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(stmtInit_arginfo)
METHOD_ARG_INFO_CONN_TWO_ARGS(shutdownServer_arginfo, 0, "level")
METHOD_ARG_INFO_CONN_TWO_ARGS(refreshServer_arginfo, 0, "options")
METHOD_ARG_INFO_CONN_ONLY_ARG(ping_arginfo)
METHOD_ARG_INFO_CONN_TWO_ARGS(killConnection_arginfo, 0, "pid")
METHOD_ARG_INFO_CONN_TWO_ARGS(selectDb_arginfo, 0, "database")
METHOD_ARG_INFO_CONN_ONLY_ARG(serverDumpDebugInformation_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(changeUser_arginfo)
	ZEND_ARG_INFO(0, "user")
	ZEND_ARG_INFO(0, "password")
	ZEND_ARG_INFO(0, "database")
	ZEND_ARG_INFO(0, "silent")
	ZEND_ARG_INFO(0, "passwd_len")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(getErrorNumber_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getErrorString_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getSqlstate_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getThreadId_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getStatistics_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getServerVersion_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getServerInformation_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getServerStatistics_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getHostInformation_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getProtocolInformation_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getLastMessage_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(charsetName_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(listFields_arginfo)
	ZEND_ARG_INFO(0, "table")
	ZEND_ARG_INFO(0, "achtung_wild")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(listMethod_arginfo)
	ZEND_ARG_INFO(0, "query")
	ZEND_ARG_INFO(0, "achtung_wild")
	ZEND_ARG_INFO(0, "par1")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(getLastInsertId_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getAffectedRows_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getWarningCount_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getFieldCount_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(getServerStatus_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(setServerOption_arginfo)
	ZEND_ARG_INFO(0, "option")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(setClientOption_arginfo)
	ZEND_ARG_INFO(0, "option")
	ZEND_ARG_INFO(0, "value")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(queryReadResultsetHeader_arginfo)
	ZEND_ARG_INFO(0, "mysqlnd_stmt")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(simpleCommand_arginfo)
	ZEND_ARG_INFO(0, "command")
	ZEND_ARG_INFO(0, "arg")
	ZEND_ARG_INFO(0, "ok_packet")
	ZEND_ARG_INFO(0, "silent")
	ZEND_ARG_INFO(0, "ignore_upsert_status")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(simpleCommandHandleResponse_arginfo)
	ZEND_ARG_INFO(0, "ok_packet")
	ZEND_ARG_INFO(0, "silent")
	ZEND_ARG_INFO(0, "command")
	ZEND_ARG_INFO(0, "ignore_upsert_status")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(restartPSession_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(endPSession_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(sendClose_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(sslSet_arginfo)
	ZEND_ARG_INFO(0, "key")
	ZEND_ARG_INFO(0, "cert")
	ZEND_ARG_INFO(0, "ca")
	ZEND_ARG_INFO(0, "capath")
	ZEND_ARG_INFO(0, "cipher")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(setAutocommit_arginfo)
	ZEND_ARG_INFO(0, "mode")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(txCommit_arginfo)
METHOD_ARG_INFO_CONN_ONLY_ARG(txRollback_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(txBegin_arginfo)
	ZEND_ARG_INFO(0, "mode")
	ZEND_ARG_INFO(0, "name")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(txCommitOrRollback_arginfo)
	ZEND_ARG_INFO(0, "commit")
	ZEND_ARG_INFO(0, "flags")
	ZEND_ARG_INFO(0, "name")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(txSavepoint_arginfo)
	ZEND_ARG_INFO(0, "name")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_BEGIN_W_CONN(txSavepointRelease_arginfo)
	ZEND_ARG_INFO(0, "name")
METHOD_ARG_INFO_END()

METHOD_ARG_INFO_CONN_ONLY_ARG(executeInitCommands_arginfo)

METHOD_ARG_INFO_BEGIN_W_CONN(getUpdatedConnectFlags_arginfo)
	ZEND_ARG_INFO(0, "mysql_flags")
METHOD_ARG_INFO_END()

static zend_function_entry php_mysqlnd_uh_class_conn_data_functions[] = {
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, query, query_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, init, init_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, connect, connect_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, escapeString, escapeString_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, setCharset, setCharset_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, sendQuery, sendQuery_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, reapQuery, reapQuery_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, useResult, useResult_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, storeResult, storeResult_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, nextResult, nextResult_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, moreResults, moreResults_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, stmtInit, stmtInit_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, shutdownServer, shutdownServer_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, refreshServer, refreshServer_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, ping, ping_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, killConnection, killConnection_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, selectDb, selectDb_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, serverDumpDebugInformation, serverDumpDebugInformation_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, changeUser, changeUser_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getErrorNumber, getErrorNumber_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getErrorString, getErrorString_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getSqlstate, getSqlstate_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getThreadId, getThreadId_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getStatistics, getStatistics_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getServerVersion, getServerVersion_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getServerInformation, getServerInformation_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getServerStatistics, getServerStatistics_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getHostInformation, getHostInformation_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getProtocolInformation, getProtocolInformation_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getLastMessage, getLastMessage_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, charsetName, charsetName_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, listFields, listFields_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, listMethod, listMethod_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getLastInsertId, getLastInsertId_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getAffectedRows, getAffectedRows_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getWarningCount, getWarningCount_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getFieldCount, getFieldCount_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getServerStatus, getServerStatus_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, setServerOption, setServerOption_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, setClientOption, setClientOption_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, queryReadResultsetHeader, queryReadResultsetHeader_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, simpleCommand, simpleCommand_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, simpleCommandHandleResponse, simpleCommandHandleResponse_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, restartPSession, restartPSession_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, endPSession, endPSession_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, sendClose, sendClose_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, sslSet, sslSet_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, setAutocommit, setAutocommit_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txCommit, txCommit_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txRollback, txRollback_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txBegin, txBegin_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txCommitOrRollback, txCommitOrRollback_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txSavepoint, txSavepoint_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, txSavepointRelease, txSavepointRelease_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, executeInitCommands, executeInitCommands_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_CONN_DATA_NAME, getUpdatedConnectFlags, getUpdatedConnectFlags_arginfo, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

/* {{{ */
void mysqlnd_uh_minit_register_class_conn_data(TSRMLS_D)
{
	/* register the classes defined by the extension during MINIT */
	zend_class_entry ce_conn;

	INIT_CLASS_ENTRY(ce_conn, MYSQLND_UH_CLASS_CONN_DATA_NAME, php_mysqlnd_uh_class_conn_data_functions);
	php_mysqlnd_uh_class_conn_data_entry = zend_register_internal_class(&ce_conn TSRMLS_CC);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
