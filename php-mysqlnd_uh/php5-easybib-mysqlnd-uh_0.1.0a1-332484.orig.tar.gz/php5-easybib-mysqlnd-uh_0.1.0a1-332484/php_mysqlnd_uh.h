	/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id: $ */

#ifndef PHP_MYSQLND_UH_H
#define PHP_MYSQLND_UH_H

/*
  Plain vanilla PHP extension infrastructuee
*/
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "mysqlnd_uh_hooks.h"

extern zend_module_entry mysqlnd_uh_module_entry;
#define phpext_mysqlnd_uh_ptr &mysqlnd_uh_module_entry

ZEND_BEGIN_MODULE_GLOBALS(mysqlnd_uh)
	zend_bool enabled;
	zend_bool report_wrong_types;
	/* default connection wrapper user object, if set */
	zval * conn_user_obj;
	zval * conn_data_user_obj;
	char * conn_error_str;
	char * conn_sqlstate;
	char * conn_server_info;
	char * conn_host_info;
	char * conn_last_message;
	char * conn_charset_name;
	/* default statement wrapper user object, if set */
	zval * stmt_user_obj;
	/* default result wrapper user object, if set */
	zval * res_user_obj;
ZEND_END_MODULE_GLOBALS(mysqlnd_uh)

extern ZEND_DECLARE_MODULE_GLOBALS(mysqlnd_uh)

#ifdef ZTS
#include "TSRM.h"
#define MYSQLND_UH_G(v) TSRMG(mysqlnd_uh_globals_id, zend_mysqlnd_uh_globals*, v)
#else
#define MYSQLND_UH_G(v) (mysqlnd_uh_globals.v)
#endif

/* Extension name and version string */
#define EXT_MYSQLND_UH_NAME 		"mysqlnd_uh"
#define PHP_MYSQLND_UH_VERSION	 	"1.1.0-alpha"
#define EXT_MYSQLND_UH_VERSION_ID	100100

/* maximum lenght of an error message from mysqlnd */
#define MYSQLND_UH_ERRMSG_SIZE MYSQLND_ERRMSG_SIZE

/* sqlstate lenght */
#define MYSQLND_UH_SQLSTATE_LENGTH (MYSQLND_SQLSTATE_LENGTH + 1)

/* A wild guess on server info(=version) length: 3.2.23-beta, 6.0-alpha, ... */
#define MYSQLND_UH_SERVER_INFO_LENGTH 256

/* A wild guess on host info length: localhost, ... */
#define MYSQLND_UH_HOST_INFO_LENGTH MYSQLND_UH_SERVER_INFO_LENGTH

/* A wild guess on the last message: TODO - find what its about */
#define MYSQLND_UH_LAST_MESSAGE_LENGTH 512

/* A wild guess on the charset name: latin1, unicode, ... */
#define MYSQLND_UH_CHARSET_NAME_LENGTH 64

/* String prefix for PHP userland error messages */
#define MYSQLND_UH_ERROR_PREFIX "(Mysqlnd User Handler)"

/* Wrapper resource for MYSQLND connection handle */
#define MYSQLND_UH_RES_MYSQLND_CONN_DATA_NAME "Mysqlnd Connection Data"
extern int le_mysqlnd_uh_mysqlnd_conn_data;

/* Wrapper resource for MYSQLND connection handle */
#define MYSQLND_UH_RES_MYSQLND_CONN_NAME "Mysqlnd Connection"
extern int le_mysqlnd_uh_mysqlnd_conn;

/* Hack - a couple of INTERNAL resources that will not be exposed to user land */
#define MYSQLND_UH_RES_MYSQLND_RESULT_NAME 	"Mysqlnd Resultset (internal only - you must not modify it!)"
extern int le_mysqlnd_uh_mysqlnd_res;

#define MYSQLND_UH_RES_MYSQLND_STMT_NAME 	"Mysqlnd Prepared Statement (internal only - you must not modify it!)"
extern int le_mysqlnd_uh_mysqlnd_stmt;
extern int le_mysqlnd_uh_mysqlnd_stmt_res;

#endif	/* PHP_MYSQLND_UH_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
