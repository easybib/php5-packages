/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_mysqlnd_uh.h"
#include "mysqlnd_uh_classes.h"
#include "mysqlnd_uh_hooks.h"

#define MYSLQND_UH_DISABLED_WARNING " The plugin has been disabled by setting the configuration parameter mysqlnd_uh.enable = false."
#define MYSQLND_UH_PROXY_DISABLED_WARNING MYSLQND_UH_DISABLED_WARNING " The proxy has not been installed "

/* mysqli zend class handler */
/* TODO: fix path */
#include "mysqli_comp_structs.h"
static zend_class_entry *mysqli_link_class_entry;

/* resources */
int le_mysqlnd_uh_mysqlnd_stmt_res;
int le_mysqlnd_uh_mysqlnd_conn;
int le_mysqlnd_uh_mysqlnd_conn_data;

static void mysqlnd_uh_do_free_plugin_connection_data(MYSQLND_UH_CONN_PLUGIN **conn_data, zend_bool handler_only, zend_bool persistent TSRMLS_DC);

/* {{{ */
/*
	Plugin related utilities --

	mysqlnd plugins can associate arbitrary data pointer with mysqlnd handlers for
	mysqlnd connections, statements, result sets, protocol and net. All of the
	mysqlnd_plugin_get_plugin_<name>_data(...) functions return **void which
	you are supposed to assign some useful memory to. Typically, you will
	want to put a struct here. Make sure to allocate persistent memory, if
	the mysqlnd connection is a persistent one. See below how to free
	the memory at the end of the lifetime of a mysqlnd connection.
*/
MYSQLND_UH_CONN_PLUGIN** mysqlnd_uh_get_plugin_connection_data_data(const MYSQLND_CONN_DATA *conn, zend_bool init_resource TSRMLS_DC) {
	MYSQLND_UH_CONN_PLUGIN **conn_data = NULL;

	DBG_ENTER("mysqlnd_uh_get_plugin_connection_data_data");
	DBG_INF_FMT("conn_data %p", conn);
/*
	if (conn->persistent) {
		DBG_INF("persistent connectin - no user handler for now");
		DBG_RETURN(conn_data);
	}
*/
	conn_data = (MYSQLND_UH_CONN_PLUGIN **) mysqlnd_plugin_get_plugin_connection_data_data(conn, mysqlnd_uh_plugin_id);
	if (conn_data && *conn_data) {
		DBG_INF("plugin data exists");
		DBG_INF_FMT("conn_data %p", *conn_data);
		/* plugin connection data allocated and not set to NULL */
		if (init_resource && !(*conn_data)->user_resource) {
			/* A bit of a hack - we need to pass the mysqlnd connection to Mysqlnd User Handler class */
			zval *conn_resource;
			MYSQLND_UH_RES_CONN* res_conn;
			MYSQLND_UH_MAKE_ZVAL(conn_resource);

			res_conn = (MYSQLND_UH_RES_CONN*)pecalloc(1, sizeof(MYSQLND_UH_RES_CONN), conn->persistent);
			DBG_INF_FMT("alloc res_conn %p, persistent = %d", res_conn, conn->persistent);
			res_conn->mysqlnd_conn_data = (MYSQLND_CONN_DATA *)conn;
			res_conn->user_conn = NULL;
			res_conn->persistent = conn->persistent;

			ZEND_REGISTER_RESOURCE(conn_resource, (void *)res_conn, le_mysqlnd_uh_mysqlnd_conn_data);
			(*conn_data)->user_resource = conn_resource;
			DBG_INF_FMT("reset resource %p", (*conn_data)->user_resource);
		}

	} else {
		DBG_INF("no plugin data");
		/*
		FIXME - HACK - TODO
		Do not allocate resources during RSHUTDOWN or you end up with double free's.
		User callbacks shall not be invoked during shutdown. We shall behave transparently.
		The lazy allocation approach should be replaced with something clever on the long run.
		*/
		if (EG(in_execution)) {
			/* no data set - allocate memory and initialize it */
			*conn_data = (MYSQLND_UH_CONN_PLUGIN *)pecalloc(1, sizeof(MYSQLND_UH_CONN_PLUGIN), conn->persistent);
			DBG_INF_FMT("alloc conn_data %p, persistent = %d", *conn_data, conn->persistent);
			if (init_resource) {
				MYSQLND_UH_RES_CONN* res_conn;
				zval *conn_resource;
				MYSQLND_UH_MAKE_ZVAL(conn_resource);

				res_conn = (MYSQLND_UH_RES_CONN*)pecalloc(1, sizeof(MYSQLND_UH_RES_CONN), conn->persistent);
				DBG_INF_FMT("alloc res_conn %p, persistent = %d", res_conn, conn->persistent);
				res_conn->mysqlnd_conn_data = (MYSQLND_CONN_DATA *)conn;
				res_conn->user_conn = NULL;
				res_conn->persistent = conn->persistent;

				ZEND_REGISTER_RESOURCE(conn_resource, (void *)res_conn, le_mysqlnd_uh_mysqlnd_conn_data);
				(*conn_data)->user_resource = conn_resource;
				DBG_INF_FMT("alloc resource %p", (*conn_data)->user_resource);
			}
		} else {
			DBG_INF("shutdown");
		}
	}

	DBG_RETURN(conn_data);
}
/* }}} */


/* {{{ */
/*
	Plugin related utilities --

	mysqlnd plugins must free their connection data using the mysqlnd methods
	end_psession() and free_contents(), if they associate plugin data with established
	mysqlnd connections. end_psession() is for persistent connections and
	free_contents() is for non-persistent connections. Take good care about
	freeing your persistent or non-persistent data parts accordingly!
*/
void mysqlnd_uh_free_plugin_connection_data_data(MYSQLND_CONN_DATA *conn, zend_bool handler_only TSRMLS_DC) {
	MYSQLND_UH_CONN_PLUGIN **conn_data;

	if (!MYSQLND_UH_G(enabled))
		return;

	DBG_ENTER("mysqlnd_uh_free_plugin_connection_data_data");
	DBG_INF_FMT("conn_data %p", conn);

	conn_data = (MYSQLND_UH_CONN_PLUGIN **) mysqlnd_plugin_get_plugin_connection_data_data(conn, mysqlnd_uh_plugin_id);
	mysqlnd_uh_do_free_plugin_connection_data(conn_data, handler_only, conn->persistent TSRMLS_CC);

	DBG_VOID_RETURN;
}
/* }}} */


MYSQLND_UH_CONN_PLUGIN** mysqlnd_uh_get_plugin_connection_data(const MYSQLND *conn, zend_bool init_resource TSRMLS_DC) {
	MYSQLND_UH_CONN_PLUGIN **conn_data = NULL;

	DBG_ENTER("mysqlnd_uh_get_plugin_connection_data");
	DBG_INF_FMT("conn %p", conn);

	conn_data = (MYSQLND_UH_CONN_PLUGIN **) mysqlnd_plugin_get_plugin_connection_data(conn, mysqlnd_uh_plugin_id);
	if (conn_data && *conn_data) {
		DBG_INF("plugin data exists");
		DBG_INF_FMT("conn_data %p", *conn_data);
		/* plugin connection data allocated and not set to NULL */
		if (init_resource && !(*conn_data)->user_resource) {
			/* A bit of a hack - we need to pass the mysqlnd connection to Mysqlnd User Handler class */
			zval *conn_resource;
			MYSQLND_UH_RES_CONN* res_conn;
			MYSQLND_UH_MAKE_ZVAL(conn_resource);

			res_conn = (MYSQLND_UH_RES_CONN*)pecalloc(1, sizeof(MYSQLND_UH_RES_CONN), conn->persistent);
			DBG_INF_FMT("alloc res_conn %p, persistent = %d", res_conn, conn->persistent);
			res_conn->mysqlnd_conn = (MYSQLND *)conn;
			res_conn->user_conn = NULL;
			res_conn->persistent = conn->persistent;

			ZEND_REGISTER_RESOURCE(conn_resource, (void *)res_conn, le_mysqlnd_uh_mysqlnd_conn);
			(*conn_data)->user_resource = conn_resource;
			DBG_INF_FMT("reset resource %p", (*conn_data)->user_resource);
			res_conn->user_resource = conn_resource;

		}

	} else {
		DBG_INF("no plugin data");
		/*
		FIXME - HACK - TODO
		Do not allocate resources during RSHUTDOWN or you end up with double free's.
		User callbacks shall not be invoked during shutdown. We shall behave transparently.
		The lazy allocation approach should be replaced with something clever on the long run.
		*/
		if (EG(in_execution)) {
			/* no data set - allocate memory and initialize it */
			*conn_data = (MYSQLND_UH_CONN_PLUGIN *)pecalloc(1, sizeof(MYSQLND_UH_CONN_PLUGIN), conn->persistent);
			DBG_INF_FMT("alloc conn_data %p, persistent = %d", *conn_data, conn->persistent);
			if (init_resource) {
				MYSQLND_UH_RES_CONN* res_conn;
				zval *conn_resource;
				MYSQLND_UH_MAKE_ZVAL(conn_resource);

				res_conn = (MYSQLND_UH_RES_CONN*)pecalloc(1, sizeof(MYSQLND_UH_RES_CONN), conn->persistent);
				DBG_INF_FMT("alloc res_conn %p, persistent = %d", res_conn, conn->persistent);
				res_conn->mysqlnd_conn = (MYSQLND *)conn;
				res_conn->user_conn = NULL;
				res_conn->persistent = conn->persistent;

				ZEND_REGISTER_RESOURCE(conn_resource, (void *)res_conn, le_mysqlnd_uh_mysqlnd_conn);
				(*conn_data)->user_resource = conn_resource;
				DBG_INF_FMT("alloc resource %p", (*conn_data)->user_resource);

				/*
				It can happen that Zend shuts down the resource list prior to mysqlnd
				calling all dtors. Means, the zval resource in conn_data will not be free'd
				in time by the corresponding mysqlnd_uh plugin dtor that free's the plugin
				memory.

				By keeping the resource zval as part of the resource itself AND
				not using a standard zval but a zval allocated using emalloc(), we can
				keep the resource's zval in the resource struct itself. Then, when
				PHP shutsdown the resource list (prior to calling our dtor), we can
				free the zval and Zend is happy. Later on in our mysqlnd dtor,
				we must make sure not to double-free.
				*/
				res_conn->user_resource = conn_resource;
			}


		} else {
			DBG_INF("shutdown");
		}
	}

	DBG_RETURN(conn_data);
}
/* }}} */


/* {{{ */
void mysqlnd_uh_free_plugin_connection_data(MYSQLND *conn, zend_bool handler_only TSRMLS_DC) {
	MYSQLND_UH_CONN_PLUGIN **conn_data;

	if (!MYSQLND_UH_G(enabled))
		return;
	DBG_ENTER("mysqlnd_uh_free_plugin_connection_data");
	DBG_INF_FMT("conn_data %p", conn);

	conn_data = (MYSQLND_UH_CONN_PLUGIN **) mysqlnd_plugin_get_plugin_connection_data(conn, mysqlnd_uh_plugin_id);
	if (conn_data && *conn_data) {
		DBG_INF("plugin data exists");
		DBG_INF_FMT("conn_data %p, persistent = %d", *conn_data, conn->persistent);

		/* free user handler object */
		if ((*conn_data)->user_obj) {
			DBG_INF_FMT("free user object %p", (*conn_data)->user_obj);
			zval_ptr_dtor(&(*conn_data)->user_obj);
			(*conn_data)->user_obj = NULL;
		}

		if (!handler_only) {
			/* do not only reset user handler but free everything */
			if (EG(in_execution)) {
				/* dtor potentially called before resource list has been destroyed and
				 resource zval has been freed by out resc_dtor */
				MYSQLND_UH_RES_CONN *res_conn;
				res_conn = (MYSQLND_UH_RES_CONN*)zend_fetch_resource(&((*conn_data)->user_resource) TSRMLS_CC, -1, MYSQLND_UH_RES_MYSQLND_CONN_NAME, NULL, 1, le_mysqlnd_uh_mysqlnd_conn);

				if ((res_conn) && (res_conn->user_resource) && ((*conn_data)->user_resource)) {
					DBG_INF_FMT("free resource %p", (*conn_data)->user_resource);

					MYSQLND_UH_DESTROY_ZVAL((*conn_data)->user_resource);
					(*conn_data)->user_resource = NULL;
					res_conn->user_resource = NULL;
				}
				if ((*conn_data)->userland_conn_id) {
					/* TODO
					DBG_INF_FMT("free userland_conn_id %p", (*conn_data)->userland_conn_id);
					mnd_pefree((*conn_data)->userland_conn_id, conn->persistent);
					(*conn_data)->userland_conn_id = NULL;
					*/
				}
			}

			DBG_INF_FMT("FREE conn_data %p, persistent = %d", *conn_data, conn->persistent);
			pefree(*conn_data, conn->persistent);
			*conn_data = NULL;
		}
	}

	DBG_VOID_RETURN;
}
/* }}} */


/* {{{ */
static void mysqlnd_uh_do_free_plugin_connection_data(MYSQLND_UH_CONN_PLUGIN **conn_data, zend_bool handler_only, zend_bool persistent TSRMLS_DC) {
	DBG_ENTER("mysqlnd_uh_do_free_plugin_connection_data");
	if (conn_data && *conn_data) {
		DBG_INF("plugin data exists");
		DBG_INF_FMT("conn_data %p, persistent = %d", *conn_data, persistent);

		/* free user handler object */
		if ((*conn_data)->user_obj) {
			DBG_INF_FMT("free user object %p", (*conn_data)->user_obj);
			zval_ptr_dtor(&(*conn_data)->user_obj);
			(*conn_data)->user_obj = NULL;
		}

		if (!handler_only) {
			/* do not only reset user handler but free everything */

			if ((*conn_data)->user_resource) {
				DBG_INF_FMT("free resource %p", (*conn_data)->user_resource);

				MYSQLND_UH_DESTROY_ZVAL((*conn_data)->user_resource);
				(*conn_data)->user_resource = NULL;
			}
			if ((*conn_data)->userland_conn_id) {
				/* TODO
				DBG_INF_FMT("free userland_conn_id %p", (*conn_data)->userland_conn_id);
				mnd_pefree((*conn_data)->userland_conn_id, conn->persistent);
				(*conn_data)->userland_conn_id = NULL;
				*/
			}

			DBG_INF_FMT("FREE conn_data %p, persistent = %d", *conn_data, persistent);
			pefree(*conn_data, persistent);
			*conn_data = NULL;
		}
	}
	DBG_VOID_RETURN;
}
/* }}} */

/* {{{ */
MYSQLND_UH_STMT_DATA** mysqlnd_uh_get_plugin_statement_data(const MYSQLND_STMT *stmt, zend_bool init_resource TSRMLS_DC) {
	MYSQLND_UH_STMT_DATA **stmt_data = NULL;

	DBG_ENTER("mysqlnd_uh_get_plugin_statement_data");
	DBG_INF_FMT("statement %p", stmt);
	stmt_data = (MYSQLND_UH_STMT_DATA **) mysqlnd_plugin_get_plugin_stmt_data(stmt, mysqlnd_uh_plugin_id);

	if (stmt_data && *stmt_data) {
		/* plugin connection data allocated and not set to NULL */
		DBG_INF("plugin data exists");
		DBG_INF_FMT("stmt_data %p", *stmt_data);

		if (init_resource && !(*stmt_data)->user_resource) {
			/* A bit of a hack - we need to pass the mysqlnd statement to Mysqlnd User Handler class */
			zval *stmt_resource;
			MAKE_STD_ZVAL(stmt_resource);
			ZEND_REGISTER_RESOURCE(stmt_resource, (void *)stmt, le_mysqlnd_uh_mysqlnd_stmt);
			(*stmt_data)->user_resource = stmt_resource;
			DBG_INF_FMT("reset resource %p", (*stmt_data)->user_resource);
		}

	} else {
		DBG_INF("no plugin data");
		/*
		FIXME - HACK - TODO
		Do not allocate resources during RSHUTDOWN or you end up with double free's.
		User callbacks shall not be invoked during shutdown. We shall behave transparently.
		The lazy allocation approach should be replaced with something clever on the long run.
		*/
		if (EG(in_execution)) {
			/* no data set - allocate memory and initialize it */
			*stmt_data = (MYSQLND_UH_STMT_DATA *)mnd_pecalloc(1, sizeof(MYSQLND_UH_STMT_DATA), 0);
			DBG_INF_FMT("alloc stmt_data %p", *stmt_data);
			if (init_resource) {
				zval *stmt_resource;
				MAKE_STD_ZVAL(stmt_resource);
				ZEND_REGISTER_RESOURCE(stmt_resource, (void *)stmt, le_mysqlnd_uh_mysqlnd_stmt);
				(*stmt_data)->user_resource = stmt_resource;
				DBG_INF_FMT("alloc resource %p", (*stmt_data)->user_resource);
			}
		} else {
			DBG_INF("shutdown");
		}
	}

	DBG_RETURN(stmt_data);
}
/* }}} */

/* {{{ */
void mysqlnd_uh_conn_free_plugin_statement_data(MYSQLND_STMT *stmt, zend_bool handler_only TSRMLS_DC) {
	MYSQLND_UH_STMT_DATA **stmt_data = NULL;

	if (!MYSQLND_UH_G(enabled))
		return;

	DBG_ENTER("mysqlnd_uh_free_plugin_statement_data");
	DBG_INF_FMT("statement %p", stmt);

	stmt_data = (MYSQLND_UH_STMT_DATA **) mysqlnd_plugin_get_plugin_stmt_data(stmt, mysqlnd_uh_plugin_id);
	if (stmt_data && *stmt_data) {
		/* free user handler object */
		DBG_INF_FMT("stmt_data %p", *stmt_data);

		if ((*stmt_data)->user_obj) {
			DBG_INF_FMT("free user object %p", (*stmt_data)->user_obj);
			zval_ptr_dtor(&(*stmt_data)->user_obj);
			(*stmt_data)->user_obj = NULL;
		}

		if (!handler_only) {
			/* do not only reset user handler but free everything */
			if ((*stmt_data)->user_resource) {
				DBG_INF_FMT("free resource %p", (*stmt_data)->user_resource);
				zval_ptr_dtor(&((*stmt_data)->user_resource));
				(*stmt_data)->user_resource = NULL;
			}

			DBG_INF_FMT("free stmt_data %p", *stmt_data);
			mnd_pefree(*stmt_data, 0);
			*stmt_data = NULL;
		}
	}

	DBG_VOID_RETURN;
}
/* }}} */


/* {{{ */
MYSQLND_UH_RESULT_DATA** mysqlnd_uh_get_plugin_result_data(const MYSQLND_RES *res, zend_bool init_resource TSRMLS_DC) {
	MYSQLND_UH_RESULT_DATA **res_data = NULL;

	DBG_ENTER("mysqlnd_uh_get_plugin_result_data");
	DBG_INF_FMT("result %p", res);
	res_data = (MYSQLND_UH_RESULT_DATA **) mysqlnd_plugin_get_plugin_result_data(res, mysqlnd_uh_plugin_id);

	if (res_data && *res_data) {
		/* plugin connection data allocated and not set to NULL */
		DBG_INF("plugin data exists");
		DBG_INF_FMT("res_data %p", *res_data);

		if (init_resource && !(*res_data)->user_resource) {
			/* A bit of a hack - we need to pass the mysqlnd result to Mysqlnd User Handler class */
			zval *res_resource;
			MAKE_STD_ZVAL(res_resource);
			ZEND_REGISTER_RESOURCE(res_resource, (void *)res, le_mysqlnd_uh_mysqlnd_res);
			(*res_data)->user_resource = res_resource;
			DBG_INF_FMT("reset resource %p", (*res_data)->user_resource);
		}

	} else {
		DBG_INF("no plugin data");
		/*
		FIXME - HACK - TODO
		Do not allocate resources during RSHUTDOWN or you end up with double free's.
		User callbacks shall not be invoked during shutdown. We shall behave transparently.
		The lazy allocation approach should be replaced with something clever on the long run.
		*/
		if (EG(in_execution)) {
			/* no data set - allocate memory and initialize it */
			*res_data = (MYSQLND_UH_RESULT_DATA *)mnd_pecalloc(1, sizeof(MYSQLND_UH_RESULT_DATA), 0);
			DBG_INF_FMT("alloc res_data %p", *res_data);
			if (init_resource) {
				zval *res_resource;
				MAKE_STD_ZVAL(res_resource);
				ZEND_REGISTER_RESOURCE(res_resource, (void *)res, le_mysqlnd_uh_mysqlnd_res);
				(*res_data)->user_resource = res_resource;
				DBG_INF_FMT("alloc resource %p", (*res_data)->user_resource);
			}
		} else {
			DBG_INF("shutdown");
		}
	}

	DBG_RETURN(res_data);
}
/* }}} */


/* {{{ */
void mysqlnd_uh_conn_free_plugin_result_data(MYSQLND_RES *res, zend_bool handler_only TSRMLS_DC) {
	MYSQLND_UH_RESULT_DATA **res_data = NULL;

	if (!MYSQLND_UH_G(enabled))
		return;

	DBG_ENTER("mysqlnd_uh_free_plugin_result_data");
	DBG_INF_FMT("result %p", res);

	res_data = (MYSQLND_UH_RESULT_DATA **) mysqlnd_plugin_get_plugin_result_data(res, mysqlnd_uh_plugin_id);
	if (res_data && *res_data) {
		/* free user handler object */
		DBG_INF_FMT("res_data %p", *res_data);

		if ((*res_data)->user_obj) {
			DBG_INF_FMT("free user object %p", (*res_data)->user_obj);
			zval_ptr_dtor(&(*res_data)->user_obj);
			(*res_data)->user_obj = NULL;
		}

		if (!handler_only) {
			/* do not only reset user handler but free everything */
			if ((*res_data)->user_resource) {
				DBG_INF_FMT("free resource %p", (*res_data)->user_resource);
				zval_ptr_dtor(&((*res_data)->user_resource));
				(*res_data)->user_resource = NULL;
			}

			DBG_INF_FMT("free res_data %p", *res_data);
			mnd_pefree(*res_data, 0);
			*res_data = NULL;
		}
	}

	DBG_VOID_RETURN;
}
/* }}} */


/*
	PHP userland utility functions not directly related to mysqlnd plugins as such
*/
PHP_FUNCTION(mysqlnd_uh_set_connection_proxy)
{
	zval *mysqlnd_uh_obj_connection;
	zval *mysqli_link = NULL;
	MY_MYSQL *mysql;
	MYSQLND_UH_CONN_PLUGIN **conn_data;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "O|O",
														&mysqlnd_uh_obj_connection, php_mysqlnd_uh_class_conn_entry,
														&mysqli_link, mysqli_link_class_entry) == FAILURE) {
		RETURN_NULL();
	}

	if (!MYSQLND_UH_G(enabled)) {
	    php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX MYSQLND_UH_PROXY_DISABLED_WARNING);
		RETURN_FALSE;
	}

	/* TODO: this should be done at a more appropriate place, m4 or MINIT or the like... */
#if !defined(MYSQLI_USE_MYSQLND)
	php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " You must be using mysqli with mysqlnd. This extension is a mysqlnd plugin.");
	RETURN_FALSE;
#endif

	if (!mysqli_link) {
		/* global default user connection object handler not restricted to a particular mysqli connection */

		if (MYSQLND_UH_G(conn_user_obj)) {
			/* free previously set handler, if any */
			zval_ptr_dtor(&(MYSQLND_UH_G(conn_user_obj)));
			MYSQLND_UH_G(conn_user_obj) = NULL;
		}

		Z_ADDREF_P(mysqlnd_uh_obj_connection);
		MYSQLND_UH_G(conn_user_obj) = mysqlnd_uh_obj_connection;

	} else {
		/* specific user handler for a certain mysqli connection */
		MYSQLND *conn;

		/* We need to unwrap the mysqlnd connection that's hidden in the mysqli handle */
		MYSQLI_FETCH_RESOURCE(mysql, MY_MYSQL*, &mysqli_link, "mysqli_link", MYSQLI_STATUS_INITIALIZED);
		conn = mysql->mysqlnd;

		/* free previously set handler, if any */
		mysqlnd_uh_free_plugin_connection_data(conn, TRUE TSRMLS_CC);

		/* (re-)set plugin connection data */
		/* TODO 1.0, conn vs. conn data */
		conn_data = mysqlnd_uh_get_plugin_connection_data(conn, TRUE TSRMLS_CC);
		if (conn_data && *conn_data) {
			Z_ADDREF_P(mysqlnd_uh_obj_connection);
			(*conn_data)->user_obj = mysqlnd_uh_obj_connection;
		} else {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " Failed to install user proxy.");
		}
	}

	RETURN_TRUE;
}

/* {{{ proto bool mysqlnd_uh_set_connection__data_proxy(object Mysqlnd User Handler[, resource mysqli_connection]) */
PHP_FUNCTION(mysqlnd_uh_set_connection_data_proxy)
{
	zval *mysqlnd_uh_obj_connection;
	zval *mysqli_link = NULL;
	MY_MYSQL *mysql;
	MYSQLND_UH_CONN_PLUGIN **conn_data;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "O|O",
														&mysqlnd_uh_obj_connection, php_mysqlnd_uh_class_conn_data_entry,
														&mysqli_link, mysqli_link_class_entry) == FAILURE) {
		RETURN_NULL();
	}

	if (!MYSQLND_UH_G(enabled)) {
	    php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX MYSQLND_UH_PROXY_DISABLED_WARNING);
		RETURN_FALSE;
	}

	/* TODO: this should be done at a more appropriate place, m4 or MINIT or the like... */
#if !defined(MYSQLI_USE_MYSQLND)
	php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " You must be using mysqli with mysqlnd. This extension is a mysqlnd plugin.");
	RETURN_FALSE;
#endif

	if (!mysqli_link) {
		/* global default user connection object handler not restricted to a particular mysqli connection */

		if (MYSQLND_UH_G(conn_data_user_obj)) {
			/* free previously set handler, if any */
			zval_ptr_dtor(&(MYSQLND_UH_G(conn_data_user_obj)));
			MYSQLND_UH_G(conn_data_user_obj) = NULL;
		}

		Z_ADDREF_P(mysqlnd_uh_obj_connection);
		MYSQLND_UH_G(conn_data_user_obj) = mysqlnd_uh_obj_connection;

	} else {
		/* specific user handler for a certain mysqli connection */
		MYSQLND *conn;

		/* We need to unwrap the mysqlnd connection that's hidden in the mysqli handle */
		MYSQLI_FETCH_RESOURCE(mysql, MY_MYSQL*, &mysqli_link, "mysqli_link", MYSQLI_STATUS_INITIALIZED);
		conn = mysql->mysqlnd;

		/* free previously set handler, if any */
		mysqlnd_uh_free_plugin_connection_data_data((conn)->data, TRUE TSRMLS_CC);

		/* (re-)set plugin connection data */
		/* TODO 1.0, conn vs. conn data */
		conn_data = mysqlnd_uh_get_plugin_connection_data_data(((conn)->data), TRUE TSRMLS_CC);
		if (conn_data && *conn_data) {
			Z_ADDREF_P(mysqlnd_uh_obj_connection);
			(*conn_data)->user_obj = mysqlnd_uh_obj_connection;
		} else {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " Failed to install user proxy.");
		}
	}

	RETURN_TRUE;
}
/* }}} */


/* {{{ proto bool mysqlnd_uh_set_statement_proxy(object Mysqlnd User Handler) */
PHP_FUNCTION(mysqlnd_uh_set_statement_proxy)
{
	zval *mysqlnd_uh_obj_stmt;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "O",
														&mysqlnd_uh_obj_stmt, php_mysqlnd_uh_class_prepared_statement_entry
														) == FAILURE) {
		RETURN_NULL();
	}

	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX MYSQLND_UH_PROXY_DISABLED_WARNING);
		RETURN_FALSE;
	}

	/* global default user connection object handler not restricted to a particular mysqli connection/statement */
	if (MYSQLND_UH_G(stmt_user_obj)) {
		/* free previously set handler, if any */
		zval_ptr_dtor(&(MYSQLND_UH_G(stmt_user_obj)));
		MYSQLND_UH_G(stmt_user_obj) = NULL;
	}

	Z_ADDREF_P(mysqlnd_uh_obj_stmt);
	MYSQLND_UH_G(stmt_user_obj) = mysqlnd_uh_obj_stmt;

	RETURN_TRUE;
}
/* }}} */


/* {{{ proto bool mysqlnd_uh_set_result_proxy(object Mysqlnd User Handler) */
PHP_FUNCTION(mysqlnd_uh_set_result_proxy)
{
	zval *mysqlnd_uh_obj_res;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "O",
														&mysqlnd_uh_obj_res, php_mysqlnd_uh_class_result_entry
														) == FAILURE) {
		RETURN_NULL();
	}

	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX MYSQLND_UH_PROXY_DISABLED_WARNING);
		RETURN_FALSE;
	}

	/* global default user connection object handler not restricted to a particular mysqli connection/statement */
	if (MYSQLND_UH_G(res_user_obj)) {
		/* free previously set handler, if any */
		zval_ptr_dtor(&(MYSQLND_UH_G(res_user_obj)));
		MYSQLND_UH_G(res_user_obj) = NULL;
	}

	Z_ADDREF_P(mysqlnd_uh_obj_res);
	MYSQLND_UH_G(res_user_obj) = mysqlnd_uh_obj_res;

	RETURN_TRUE;
}
/* }}} */


/* {{{ proto resource mysqlnd mysqlnd_uh_convert_to_mysqlnd(mixed connection_handle) */
static PHP_FUNCTION(mysqlnd_uh_convert_to_mysqlnd)
{
	zval *handle;
	MYSQLND_UH_RES_CONN* res_conn;
	MYSQLND *conn;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "z", &handle) == FAILURE) {
		return;
	}

	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX MYSLQND_UH_DISABLED_WARNING " You are not allowed to call this function." );
		RETURN_FALSE;
	}

/* TODO: this should be done at a more appropriate place, m4 or MINIT or the like... */
#if !defined(MYSQLI_USE_MYSQLND)
	php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " You must be using mysqli with mysqlnd. This extension is a mysqlnd plugin.");
	RETURN_FALSE;
#endif

	conn = zval_to_mysqlnd(handle TSRMLS_CC);
	if (!conn) {
		RETURN_NULL();
	}

	Z_ADDREF_P(handle);
	res_conn = (MYSQLND_UH_RES_CONN*)pecalloc(1, sizeof(MYSQLND_UH_RES_CONN), conn->persistent);
	res_conn->mysqlnd_conn = conn;
	res_conn->mysqlnd_conn_data = (conn)->data;
	res_conn->user_conn = handle;

	ZEND_REGISTER_RESOURCE(return_value, (void *)res_conn, le_mysqlnd_uh_mysqlnd_conn_data);
}
/* }}} */

ZEND_BEGIN_ARG_INFO_EX(mysqlnd_uh_convert_to_mysqlnd_arginfo, ZEND_SEND_BY_VAL, ZEND_RETURN_VALUE, 1)
	ZEND_ARG_INFO(0, object)
ZEND_END_ARG_INFO()
/*
  PHP Infrastructure
*/

/* Function arguments and function list */

ZEND_BEGIN_ARG_INFO_EX(mysqlnd_uh_set_connection_proxy_arginfo, ZEND_SEND_BY_VAL, ZEND_RETURN_VALUE, 1)
	ZEND_ARG_OBJ_INFO(1, MYSQLND_UH_CLASS_CONNECTION_NAME " object", MysqlndUhConnection, 0)
	ZEND_ARG_OBJ_INFO(1, "mysqli link", mysqli, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(mysqlnd_uh_set_connection_data_proxy_arginfo, ZEND_SEND_BY_VAL, ZEND_RETURN_VALUE, 1)
	ZEND_ARG_OBJ_INFO(1, MYSQLND_UH_CLASS_CONN_DATA_NAME " object", MysqlndUhConnectionData, 0)
	ZEND_ARG_OBJ_INFO(1, "mysqli link", mysqli, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(mysqlnd_uh_set_statement_proxy_arginfo, ZEND_SEND_BY_VAL, ZEND_RETURN_VALUE, 1)
	ZEND_ARG_OBJ_INFO(1, MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME " object", MysqlndUhPreparedStatement, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(mysqlnd_uh_set_result_proxy_arginfo, ZEND_SEND_BY_VAL, ZEND_RETURN_VALUE, 1)
	ZEND_ARG_OBJ_INFO(1, MYSQLND_UH_CLASS_RESULT_NAME " object", MysqlndUhResult, 0)
ZEND_END_ARG_INFO()

const zend_function_entry mysqlnd_uh_functions[] = {
	PHP_FE(mysqlnd_uh_set_connection_proxy, mysqlnd_uh_set_connection_proxy_arginfo)
	PHP_FE(mysqlnd_uh_set_connection_data_proxy, mysqlnd_uh_set_connection_data_proxy_arginfo)
	PHP_FE(mysqlnd_uh_set_statement_proxy, mysqlnd_uh_set_statement_proxy_arginfo)
	PHP_FE(mysqlnd_uh_convert_to_mysqlnd, mysqlnd_uh_convert_to_mysqlnd_arginfo)
	PHP_FE(mysqlnd_uh_set_result_proxy, mysqlnd_uh_set_result_proxy_arginfo)
	{NULL, NULL, NULL}	/* Must be the last line in mysqlnd_uh_functions[] */
};


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
