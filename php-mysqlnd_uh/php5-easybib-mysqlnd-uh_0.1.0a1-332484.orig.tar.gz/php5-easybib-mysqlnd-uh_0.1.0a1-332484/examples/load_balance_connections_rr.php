﻿<?php
/*
* Example: Load Balancing of connections using round-robin
*
* Scenario:
*
* 	You have a number of mirrored database servers. All servers hold
* 	all data you need. All servers are in house: connection times and distance
* 	are about the same. You would like to direct PHP MySQL connections to the servers
* 	in a round-robin fashion.
*
*	You have an application that you do not want to touch. You can, however,
*	install an auto_prepend script. It is not a big deal. And you are willing
* 	to hook into the database driver of your choice: mysqlnd, what else ;-).
*	See also http://www.slideshare.net/nixnutz/the-power-of-mysqlnd-plugins et al.
*
* Solution:
* 	You hook the mysqlnd library calls using mysqlnd_uh. The mysqlnd_uh script
*	is run via auto_prepend. If a client
*	calls connect() you inspect the connection parameter and decide if
*	the client may connect to the desired database server or, you pick
*	a server and change the clients connection parameter.
*
* This code works with all PHP MySQL extensions: mysql, mysqli, PDO_MySQL.
* NOTE: You must set connection properties manually at the end of the script. 
* Search for TODO!
*/

die("Please set connection properties before running! Search for TODO!\n");

class load_balancer_rr extends MySQLndUhConnection {

	/* Your database servers, list can come from anywhere */
	protected $servers;
	protected $server_count;
	
	protected $verbose;
	
	/** Sets the pre-defined list of load balancing servers 
	* 
	* See pick_server() - you can use much more sophisticated solutions, if you want.
	*/
	public function __construct($servers, $verbose) {
		$this->servers = $servers;
		$this->server_count = count($servers);
		$this->verbose = $verbose;
	}

	/** Picks a server from a pool to connect the client to 
	*
	* This function serves as an example of a callback that decides which
	* server to connect to based. The function can be of arbitrary complexity.
	* This example one is very simple and does not do anything meaningful
	* but your own implementation of the function could be much more sophisticated.
	* You could, for example, fetch the list of available database servers
	* from from a shared memory segment, a database table or a memcache server
	* serving as a central place to list which database servers are avaiable for 
	* round robin.
	*/
	public function pick_server($host, $user, $passwd, $db, $port, $socket, $mysql_flags) {

		$server = array(
			'host' => $host,
			'user' => $user,
			'passwd' => $passwd,
			'db' => $db,
			'port' => $port,
			'socket' => $socket,
			'mysql_flags' => $mysql_flags
		);
		
		/* 
		Let us assume your give the application developer some freedom to bypass
		the load balancer logic. Via a special value in the host he is allowed to 
		connect to a certain MySQL server. 
		*/
		if ("bypass_lb:" == substr($host, 0, 10)) {
			/*
			Application developer wants to bypass load balancer, 
			e.g. to fetch load balancer configuration from a MySQL database
			server that holds a list of load balancing servers 
			*/
			$server['host'] = substr($host, 11);
			if ($this->verbose)
				printf("\tpick_server() - bypassing load balancer\n");
			
		} else {
			/* Application developer is fine with round-robin */
			$rand = mt_rand(0, $this->server_count - 1);
			$server['host'] = $this->servers[$rand];
			if ($this->verbose)
				printf("\tpick_server() - load balancer has picked random server\n");
		}
		
		return $server;
	}

	/**
	* Mysqlnd library callback: connect()
	*
	* This function is called by the mysqlnd library (via the mysqlnd_uh extension)
	* whenever any of the PHP MySQL extensions (mysql, mysqli, PDO_MYSQL) tries to
	* establish a connection. The function is supposed to do the connection establishment.
	* The function call is transparent from the point of view of a PHP MySQL application.
	* We are hooking the database library.
	*/
	public function connect($res, $host, $user, $passwd, $db, $port, $socket, $mysql_flags) {
		
		if ($this->verbose)
			printf("\tconnect() - user tries to establish connection, calling load balancer\n");
			
		$server = $this->pick_server($host, $user, $passwd, $db, $port, $socket, $mysql_flags);
		/* 
		Pass the new connection properties down to the mysqlnd library 
		and let it do the actual connect. You must call the myqslnd libraries 
		connect function. If you do not, expect a crash. Sounds bad? Well,
		we are manipulating the inner workings of the database library, this is
		not for sissies...
		*/
		if ($this->verbose)
			printf("\tconnect() - load balancer has done its work, calling mysqlnd for connect\n");
			
		return parent::connect($res, 
			$server['host'], $server['user'], $server['passwd'], 
			$server['db'], $server['port'], $server['socket'], 
			$server['mysql_flags']);
	}

}

/* Create proxy object and pass list of participating servers to it */
$server_list = array('localhost', 'localhost');
$debug_info = true;
$rr = new load_balancer_rr($server_list, $debug_info);

/* Install mysqlnd proxy */
mysqlnd_uh_set_connection_proxy($rr);

/* Establish some connections */
printf("Starting load balancer demo\n");
if (!extension_loaded("mysqli")) {
	printf("You don't have compiled your PHP with mysqli support, can't demo mysqli...\n");
} else {
	printf("Your PHP supports mysqli, running demo..\n");
	/* TODO: change this to match your setup! */
	$mysqli = new mysqli('localhost', 'root', 'root', 'test', 3306, '/tmp/mysql.sock');
	if (!$mysqli) {
		printf("Can't connect, check arguments, [%d] %s\n", $mysqli->connect_errno, $mysqli->connect_error);
	} else {
		$res = $mysqli->query("SELECT 'mysqli greets you!' AS _greeting FROM DUAL");
		$row = $res->fetch_assoc();
		$res->free();
		$mysqli->close();
		printf("Connected via mysqli,  MySQL says '%s'\n", $row['_greeting']);
	}
}

printf("\n");

if (!extension_loaded("pdo_mysql")) {
	printf("You don't have compiled your PHP with PDO_MYSQL support, can't demo mysqli...\n");
} else {
	printf("Your PHP supports PDO_MYSQL, running demo..\n");
	
	/* TODO: change this to match your setup! */
	try {
		$pdo = new PDO("mysql:host=localhost;port=3306;unix_socket=/tmp/mysql.sock;dbname=test", "root", "root");
		$stmt = $pdo->query("SELECT 'PDO_MYSQL greets you!' AS _greeting FROM DUAL");
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		printf("Connected via PDO_MYSQL, MySQL says '%s'\n", $row['_greeting']);
	} catch (PDOException $e) {
		printf("Can't connect, check arguments, %s\n", $e->getMessage());
	}
}

printf("\n");
printf("No, I'm not gonna demo the use of the mysql extention. Use mysqli, forget about mysql!\n\n");
?>