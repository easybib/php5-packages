/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Ulf Wendel <uw@php.net>                                      |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "mysqlnd_uh_hooks.h"
#include "mysqlnd_uh_classes.h"
#include "php_mysqlnd_uh.h"

/* resources */
zend_class_entry *php_mysqlnd_uh_class_result_entry;

/* mysqlnd plugin related */

/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_RESULT_NAME, __construct)
{
	if (!MYSQLND_UH_G(enabled)) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED);
		RETURN_FALSE;
	}
}
/* }}} */


/* typedef void  (*func_mysqlnd_res__fetch_into)(MYSQLND_RES *result, unsigned int flags, zval *return_value, enum_mysqlnd_extension ext TSRMLS_DC ZEND_FILE_LINE_DC); */
/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_RESULT_NAME, fetchInto)
{
	MYSQLND_RES *result;
	zval* mysqlnd_res_rsrc;
	zval* mysqlnd_return_value;
	long flags;
	long extension;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rzll", &mysqlnd_res_rsrc, &mysqlnd_return_value, &flags, &extension) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(result, MYSQLND_RES*, &mysqlnd_res_rsrc, -1, MYSQLND_UH_RES_MYSQLND_RESULT_NAME, le_mysqlnd_uh_mysqlnd_res);
	org_mysqlnd_res_methods.fetch_into(result, (int)flags, mysqlnd_return_value, (int)extension TSRMLS_CC ZEND_FILE_LINE_CC);
}
/* }}} */


/* typedef enum_func_status MYSQLND_METHOD(mysqlnd_uh_result, free_result)(MYSQLND_RES * result, zend_bool implicit TSRMLS_DC) */
/* {{{ */
PHP_METHOD(MYSQLND_UH_CLASS_RESULT_NAME, freeResult)
{
	MYSQLND_RES *result;
	zval* mysqlnd_res_rsrc;
	zend_bool implicit;

	CHECK_ENABLED();
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rb", &mysqlnd_res_rsrc, &implicit) == FAILURE) {
		RETURN_NULL();
	}
	ZEND_FETCH_RESOURCE(result, MYSQLND_RES*, &mysqlnd_res_rsrc, -1, MYSQLND_UH_RES_MYSQLND_RESULT_NAME, le_mysqlnd_uh_mysqlnd_res);

	if (PASS == org_mysqlnd_res_methods.free_result(result, implicit TSRMLS_CC)) {
		RETVAL_TRUE;
	} else {
		RETVAL_FALSE;
	}
}
/* }}} */


/* mysqlnd result class */
struct st_mysqlnd_res_methods org_mysqlnd_res_methods;

/* PHP Infrastructure */
#define METHOD_ARG_INFO_BEGIN_W_RESULT(method) \
	ZEND_BEGIN_ARG_INFO(method, 0) \
		ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_RESULT_NAME)

#define METHOD_ARG_INFO_END() \
	ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO(fetchInto_arginfo, 0)
	ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_RESULT_NAME)
	ZEND_ARG_INFO(1, "row")
	ZEND_ARG_INFO(0, "flags")
	ZEND_ARG_INFO(0, "extension")
METHOD_ARG_INFO_END()

ZEND_BEGIN_ARG_INFO(freeResult_arginfo, 0)
	ZEND_ARG_INFO(0, MYSQLND_UH_RES_MYSQLND_RESULT_NAME)
	ZEND_ARG_INFO(0, "implicit")
METHOD_ARG_INFO_END()

static zend_function_entry php_mysqlnd_uh_class_result_functions[] = {
	PHP_ME(MYSQLND_UH_CLASS_RESULT_NAME, __construct, NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(MYSQLND_UH_CLASS_RESULT_NAME, fetchInto, fetchInto_arginfo, ZEND_ACC_PUBLIC)
	PHP_ME(MYSQLND_UH_CLASS_RESULT_NAME, freeResult, freeResult_arginfo, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

/* {{{ */
void mysqlnd_uh_minit_register_class_result(TSRMLS_D)
{
	/* register the classes defined by the extension during MINIT */
	zend_class_entry ce_conn;

	INIT_CLASS_ENTRY(ce_conn, MYSQLND_UH_CLASS_RESULT_NAME, php_mysqlnd_uh_class_result_functions);
	php_mysqlnd_uh_class_result_entry = zend_register_internal_class(&ce_conn TSRMLS_CC);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
