/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id: $ */

#ifndef PHP_MYSQLND_UH_CLASSES_H
#define PHP_MYSQLND_UH_CLASSES_H

/*
	Class names
	NOTE: don't use quotes - it will break with ZEND_ARG_OBJ_INFO
*/
#define MYSQLND_UH_CLASS_CONN_NAME "MysqlndUhConnection"
#define MYSQLND_UH_CLASS_CONN_DATA_NAME "MysqlndUhConnectionData"
#define MYSQLND_UH_CLASS_PREPARED_STATEMENT_NAME "MysqlndUhPreparedStatement"
#define MYSQLND_UH_CLASS_RESULT_NAME "MysqlndUhResult"

#define MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED MYSQLND_UH_ERROR_PREFIX " The plugin has been disabled by setting the configuration parameter mysqlnd_uh.enable = false.  You should not use any of the base classes"

/* PHP infrastructure: class registration */
/*
  MINIT hooks and global class entry pointer: connection and statement class
*/
void mysqlnd_uh_minit_register_class_conn(TSRMLS_D);
void mysqlnd_uh_minit_register_class_conn_data(TSRMLS_D);
void mysqlnd_uh_minit_register_class_statement(TSRMLS_D);
void mysqlnd_uh_minit_register_class_result(TSRMLS_D);

extern zend_class_entry *php_mysqlnd_uh_class_conn_entry;
extern zend_class_entry *php_mysqlnd_uh_class_conn_data_entry;
extern zend_class_entry *php_mysqlnd_uh_class_prepared_statement_entry;
extern zend_class_entry *php_mysqlnd_uh_class_result_entry;

/*
A dirty hack for calling methods from C, copied from zend_interfaces.h/zend_interfaces.c.
Unfortunately Zend does not export those calls :-(
*/
zval* mysqlnd_uh_call_method(zval **object_pp, zend_class_entry *obj_ce, zend_function **fn_proxy, char *function_name, int function_name_len, zval **retval_ptr_ptr, int param_count, zval* arg1, zval* arg2, zval* arg3, zval* arg4, zval* arg5, zval* arg6, zval *arg7, zval *arg8, zval *arg9, zval *arg10  TSRMLS_DC);

#define mysqlnd_uh_call_method_with_0_params(obj, fn_proxy, function_name, retval) \
	mysqlnd_uh_call_method(&(obj),  Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_1_params(obj, fn_proxy, function_name, retval, arg1) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 1, arg1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_2_params(obj, fn_proxy, function_name, retval, arg1, arg2) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 2, arg1, arg2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_3_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 3, arg1, arg2, arg3, NULL, NULL, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_4_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 4, arg1, arg2, arg3, arg4, NULL, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_5_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 5, arg1, arg2, arg3, arg4, arg5, NULL, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_6_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5, arg6) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 6, arg1, arg2, arg3, arg4, arg5, arg6, NULL, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_7_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 7, arg1, arg2, arg3, arg4, arg5, arg6, arg7, NULL, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_8_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 8, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, NULL, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_9_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 9, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, NULL TSRMLS_CC)

#define mysqlnd_uh_call_method_with_10_params(obj, fn_proxy, function_name, retval, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10) \
	mysqlnd_uh_call_method(&(obj), Z_OBJCE_P(obj), fn_proxy, function_name, sizeof(function_name)-1, (retval), 10, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10 TSRMLS_CC)

#define CHECK_ENABLED() \
	if (!MYSQLND_UH_G(enabled)) { \
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSLQND_UH_WARNING_CLASS_PLUGIN_DISABLED); \
		RETURN_FALSE; \
	}

#endif	/* PHP_MYSQLND_UH_CLASSES_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
