/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Authors: David Soria Parra <david.soria_parra@mayflower.de>          |
  |          Ulf Wendel <ulf.wendel@phpdoc.de>                           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_mysqlnd_uh.h"
#include "mysqlnd_uh_classes.h"
#include "mysqlnd_uh_hooks.h"

/* mysqli zend class handler */
/* TODO: fix path */
#include "mysqli_comp_structs.h"

#define EXTRACT_DATA_AND_USER_OBJ(mysqlnd_res, plugin_data, user_hook_obj) \
	MYSQLND_UH_RESULT_DATA **plugin_data; \
	zval *user_hook_obj = NULL; \
	plugin_data = (MYSQLND_UH_RESULT_DATA **) mysqlnd_uh_get_plugin_result_data((const MYSQLND_RES*)mysqlnd_res, TRUE TSRMLS_CC); \
	if (plugin_data) \
		user_hook_obj = (*plugin_data && (*plugin_data)->user_obj) ? (*plugin_data)->user_obj : MYSQLND_UH_G(res_user_obj);

#define RETVAL_BOOL_CHECK_TYPE(retval, method_name) \
	MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, IS_BOOL, "boolean", MYSQLND_UH_CLASS_RESULT_NAME)

/*
	mysqlnd function tables for connections. See below how to
	set and modify them to make them call your mysqlnd hooks.

	(You would probably declare both of them static, however,
	I need one of them in mysqlnd_uh_classes.c)
*/
static struct st_mysqlnd_res_methods *my_mysqlnd_res_methods;

/* mysqlnd result class */
struct st_mysqlnd_res_methods org_mysqlnd_res_methods;

/* {{{ */
void MYSQLND_METHOD(mysqlnd_uh_result, fetch_into)(MYSQLND_RES *result, unsigned int flags, zval *return_value, enum_mysqlnd_extension ext TSRMLS_DC ZEND_FILE_LINE_DC) {

	DBG_ENTER("mysqlnd_uh_result.fetch_into");
	DBG_INF_FMT("result %p", result);

	EXTRACT_DATA_AND_USER_OBJ(result, result_data, result_obj);

	if (result_obj) {
		MYSQLND_UH_HOOK_ARG_RESOURCE(res_resource, result_data);
		MYSQLND_UH_HOOK_ARG_LONG(flags);
		MYSQLND_UH_HOOK_ARG_LONG(ext);

		mysqlnd_uh_call_method_with_4_params(result_obj, NULL, "fetchinto", NULL, res_resource, return_value, zv_flags, zv_ext);
		zval_ptr_dtor(&zv_flags);
		zval_ptr_dtor(&zv_ext);

		if ((Z_TYPE_P(return_value) != IS_ARRAY) && (Z_TYPE_P(return_value) != IS_NULL)) {
			RETVAL_NULL();
			if (MYSQLND_UH_G(report_wrong_types))
				php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " The method " MYSQLND_UH_CLASS_RESULT_NAME "::fetchInto() has changed the row parameter to a type other than array or NULL. Setting row to NULL");
		}

	} else {
		org_mysqlnd_res_methods.fetch_into(result, flags, return_value, ext TSRMLS_CC ZEND_FILE_LINE_CC);
	}
	DBG_VOID_RETURN;

}
/* }}} */


/* {{{ */
enum_func_status MYSQLND_METHOD(mysqlnd_uh_result, free_result)(MYSQLND_RES * result, zend_bool implicit TSRMLS_DC) {
	enum_func_status ret = FAIL;

	DBG_ENTER("mysqlnd_uh_res.free_result");
	DBG_INF_FMT("result %p", result);

	EXTRACT_DATA_AND_USER_OBJ(result, result_data, result_obj);

	if (result_obj) {
		MYSQLND_UH_HOOK_ARG_RESOURCE(res_resource, result_data);
		MYSQLND_UH_HOOK_ARG_BOOL(implicit);

		mysqlnd_uh_conn_free_plugin_result_data(result, TRUE TSRMLS_CC);

		zval *retval = NULL;
		mysqlnd_uh_call_method_with_2_params(result_obj, NULL, "freeresult", &retval, res_resource, zv_implicit);
		zval_ptr_dtor(&zv_implicit);

		RETVAL_BOOL_CHECK_TYPE(retval, "freeResult");
		MYSQLND_UH_HOOK_RETVAL_BOOL_TO_FUNC_STATUS(retval, ret);

	} else {
		mysqlnd_uh_conn_free_plugin_result_data(result, FALSE TSRMLS_CC);
		ret = org_mysqlnd_res_methods.free_result(result, implicit TSRMLS_CC);
	}

	DBG_RETURN(ret);
}
/* }}} */


/* {{{ */
/*
	Registration of a mysqlnd plugin and setting hooks:
		a) obtain unique plugin id (php_mysqlnd_uh.c)
		b) get mysqlnd function lookup table for connection, statement,
		   resultset, protocol or net stuff (mysqlnd_uh_hooks_*.c)
		c) copy, modify and install new function lookup table (mysqlnd_uh_hooks_*.c)
*/
void mysqlnd_uh_minit_register_hooks_result(TSRMLS_D)
{
	/* Get pointer to result methods */
	my_mysqlnd_res_methods = mysqlnd_result_get_methods();

	/* Backup originial function pointers in org_mysqlnd_res_methods */
	memcpy(&org_mysqlnd_res_methods, my_mysqlnd_res_methods, sizeof(struct st_mysqlnd_res_methods));

	/* Replace selected methods */
	my_mysqlnd_res_methods->fetch_into						= MYSQLND_METHOD(mysqlnd_uh_result, fetch_into);
	my_mysqlnd_res_methods->free_result						= MYSQLND_METHOD(mysqlnd_uh_result, free_result);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
