/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: David Soria Parra <david.soria_parra@mayflower.de>           |
  +----------------------------------------------------------------------+
*/

/* $Id:  $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_mysqlnd_uh.h"
#include "mysqlnd_uh_classes.h"
#include "mysqlnd_uh_hooks.h"

#define RETVAL_BOOL_CHECK_TYPE(retval, method_name) \
	MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, IS_BOOL, "boolean", MYSQLND_UH_CLASS_CONN_NAME)

#define RETVAL_BOOL_TO_FUNC_STATUS(retval, ret) \
	MYSQLND_UH_HOOK_RETVAL_BOOL_TO_FUNC_STATUS(retval, ret)

#define EXTRACT_DATA_AND_USER_OBJ(mysqlnd_conn, plugin_data, user_hook_obj) \
	MYSQLND_UH_CONN_PLUGIN **plugin_data; \
	zval *user_hook_obj = NULL; \
	plugin_data = (MYSQLND_UH_CONN_PLUGIN **) mysqlnd_uh_get_plugin_connection_data((const MYSQLND*)mysqlnd_conn, TRUE TSRMLS_CC); \
	if (plugin_data) \
		user_hook_obj = (*plugin_data && (*plugin_data)->user_obj) ? (*plugin_data)->user_obj : MYSQLND_UH_G(conn_user_obj);


/* mysqli zend class handler */
/* TODO: fix path */
#include "mysqli_comp_structs.h"

/* resources */

/*
	mysqlnd function tables for connections. See below how to
	set and modify them to make them call your mysqlnd hooks.

	(You would probably declare both of them static, however,
	I need one of them in mysqlnd_uh_classes.c)
*/
static struct st_mysqlnd_conn_methods *my_mysqlnd_conn_methods;

/* {{{ enum_func_status MYSQLND_METHOD(mysqlnd_uh_conn, connect)(MYSQLND *conn, const char *host, const char * user, const char * passwd,
			unsigned int passwd_len, const char * db, unsigned int db_len, unsigned int port, const char * socket, unsigned int mysql_flags) */
enum_func_status MYSQLND_METHOD(mysqlnd_uh_conn, connect)(MYSQLND *conn, const char *host, const char * user,
	const char * passwd, unsigned int passwd_len, const char * db, unsigned int db_len,
	unsigned int port, const char * mysql_socket, unsigned int mysql_flags TSRMLS_DC) {
	enum_func_status ret = FAIL;

	DBG_ENTER("mysqlnd_uh_conn.connect");
	DBG_INF_FMT("connection %p", conn);

	EXTRACT_DATA_AND_USER_OBJ(conn, conn_data, conn_obj);
	if (conn_obj) {
	    zval *zv_host;
		zval *zv_mysql_socket;

		MYSQLND_UH_HOOK_ARG_RESOURCE(conn_resource, conn_data);
		MAKE_STD_ZVAL(zv_host);
		if (host) {
		  ZVAL_STRINGL(zv_host, host, strlen(host), 1);
		} else {
		  ZVAL_NULL(zv_host);
		}
		MYSQLND_UH_HOOK_ARG_STRING(user);
		/* KLUDGE - passwd_len is always 0 ! mysqlnd issue ?! */
		MYSQLND_UH_HOOK_ARG_STRING_LEN(passwd, (passwd) ? strlen(passwd) : 0);
		MYSQLND_UH_HOOK_ARG_STRING_LEN(db, db_len);
		MYSQLND_UH_HOOK_ARG_LONG(port);

		MAKE_STD_ZVAL(zv_mysql_socket);
		if (mysql_socket) {
		  ZVAL_STRINGL(zv_mysql_socket, mysql_socket, strlen(mysql_socket), 1);
		} else {
		  ZVAL_NULL(zv_mysql_socket);
		}

		MYSQLND_UH_HOOK_ARG_LONG(mysql_flags);

		zval *retval = NULL;
		mysqlnd_uh_call_method_with_8_params(conn_obj, NULL, "connect", &retval, conn_resource,
			zv_host, zv_user, zv_passwd, zv_db, zv_port, zv_mysql_socket, zv_mysql_flags);

		zval_ptr_dtor(&zv_host);
		zval_ptr_dtor(&zv_user);
		zval_ptr_dtor(&zv_passwd);
		zval_ptr_dtor(&zv_db);
		zval_ptr_dtor(&zv_port);
		zval_ptr_dtor(&zv_mysql_socket);
		zval_ptr_dtor(&zv_mysql_flags);

		RETVAL_BOOL_CHECK_TYPE(retval, "connect");
		RETVAL_BOOL_TO_FUNC_STATUS(retval, ret);
	} else {
		ret = org_mysqlnd_conn_methods.connect(conn, host, user, passwd, passwd_len, db, db_len, port, mysql_socket, mysql_flags TSRMLS_CC);
	}

	DBG_RETURN(ret);
}
/* }}} */


/* {{{ */
enum_func_status MYSQLND_METHOD(mysqlnd_uh_conn, close)(MYSQLND *conn, enum_connection_close_type close_type TSRMLS_DC) {
	enum_func_status ret = FAIL;

	DBG_ENTER("mysqlnd_uh_conn.close");
	DBG_INF_FMT("connection %p", conn);

	EXTRACT_DATA_AND_USER_OBJ(conn, conn_data, conn_obj);
	if (conn_obj) {
		MYSQLND_UH_HOOK_ARG_RESOURCE(conn_resource, conn_data);
		MYSQLND_UH_HOOK_ARG_LONG(close_type);
		zval *retval = NULL;
		mysqlnd_uh_call_method_with_2_params(conn_obj, NULL, "close", &retval, conn_resource, zv_close_type);
		zval_ptr_dtor(&zv_close_type);
		RETVAL_BOOL_CHECK_TYPE(retval, "close");
		RETVAL_BOOL_TO_FUNC_STATUS(retval, ret);
	} else {
		ret = org_mysqlnd_conn_methods.close(conn, close_type TSRMLS_CC);
	}

	DBG_RETURN(ret);
}
/* }}} */

/* {{{ */
void MYSQLND_METHOD(mysqlnd_uh_conn, dtor)(MYSQLND * conn TSRMLS_DC) {
	DBG_ENTER("mysqlnd_uh_conn.dtor (private)");
	DBG_INF_FMT("connection %p", conn);

	/* TODO: can this call go through userspace or not? */
	mysqlnd_uh_free_plugin_connection_data(conn, FALSE TSRMLS_CC);
	org_mysqlnd_conn_methods.dtor(conn TSRMLS_CC);

	DBG_VOID_RETURN;
}
/* }}} */

/* {{{ */
/*
	Registration of a mysqlnd plugin and setting hooks:
		a) obtain unique plugin id (php_mysqlnd_uh.c)
		b) get mysqlnd function lookup table for connection, statement,
		   resultset, protocol or net stuff (mysqlnd_uh_hooks_*.c)
		c) copy, modify and install new function lookup table (mysqlnd_uh_hooks_*.c)
*/
void mysqlnd_uh_minit_register_hooks_connection(TSRMLS_D)
{
	/* Get pointer to connection methods */
	my_mysqlnd_conn_methods = mysqlnd_conn_get_methods();

	/* Backup originial function pointers in org_mysqlnd_conn_methods */
	memcpy(&org_mysqlnd_conn_methods, my_mysqlnd_conn_methods, sizeof(struct st_mysqlnd_conn_methods));

	/*
	 TODO
	func_mysqlnd_data__connect connect;
	func_mysqlnd_conn__clone_object clone_object;
	func_mysqlnd_conn__dtor dtor;
	func_mysqlnd_conn__close close;
    */

	/* Replace selected hooks */
    my_mysqlnd_conn_methods->connect						= MYSQLND_METHOD(mysqlnd_uh_conn, connect);
	my_mysqlnd_conn_methods->close							= MYSQLND_METHOD(mysqlnd_uh_conn, close);
	my_mysqlnd_conn_methods->dtor							= MYSQLND_METHOD(mysqlnd_uh_conn, dtor);

}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
