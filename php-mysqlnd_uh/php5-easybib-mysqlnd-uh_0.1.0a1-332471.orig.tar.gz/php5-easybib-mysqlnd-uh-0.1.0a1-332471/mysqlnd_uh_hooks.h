/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2010 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Authors:                                                             |
  +----------------------------------------------------------------------+
*/

/* $Id: $ */

#ifndef MYSQLND_UH_HOOKS_H
#define MYSQLND_UH_HOOKS_H

#ifdef ZTS
#include "TSRM.h"
#endif


#ifdef PHP_WIN32
#define PHP_MYSQLND_UH_API __declspec(dllexport)
#else
# if defined(__GNUC__) && __GNUC__ >= 4
#  define PHP_MYSQLND_UH_API __attribute__ ((visibility("default")))
# else
#  define PHP_MYSQLND_UH_API
# endif
#endif

#define PHP_MYSQLND_UH_EXPORT(__type) PHP_MYSQLND_UH_API __type

extern const zend_function_entry mysqlnd_uh_functions[6];

/*
	MySQLnd Plugin related
*/
#include "ext/mysqlnd/mysqlnd.h"
#include "ext/mysqlnd/mysqlnd_debug.h"
#include "ext/mysqlnd/mysqlnd_priv.h"
#include "ext/mysqlnd/mysqlnd_ext_plugin.h"
#include "ext/mysqlnd/mysqlnd_reverse_api.h"
#include "ext/mysqlnd/mysqlnd_alloc.h"

/* mysqlnd_result_get_methods */
#include "ext/mysqlnd/mysqlnd_result.h"

/* mysqlnd plugin id */
extern unsigned int mysqlnd_uh_plugin_id;

/* function handler tables */
/*
mysqlnd_uh_hooks_conn_data.c, mysqlnd_uh_hooks_conn.c
the build-in mysqlnd_uh_connection class shall be able to call mysqlnd handler
*/
extern struct st_mysqlnd_conn_methods org_mysqlnd_conn_methods;

extern struct st_mysqlnd_conn_data_methods org_mysqlnd_conn_data_methods;

/*
mysqlnd_uh_hooks_statement.c
the build-in mysqlnd_uh_prepared_statement class shall be able to call mysqlnd handler
*/
extern struct st_mysqlnd_stmt_methods org_mysqlnd_stmt_methods;

/*
mysqlnd_uh_hooks_result.c
the build-in mysqlnd_uh_result class shall be able to call mysqlnd handler
*/
extern struct st_mysqlnd_res_methods org_mysqlnd_res_methods;

/* data which we will associate with a mysqlnd connection */


typedef struct st_mysqlnd_uh_conn {
	zval* user_obj;
	zval* user_resource;
	char* userland_conn_id;
} MYSQLND_UH_CONN_PLUGIN;

MYSQLND_UH_CONN_PLUGIN** mysqlnd_uh_get_plugin_connection_data(const MYSQLND *conn, zend_bool init_resource TSRMLS_DC);
void mysqlnd_uh_free_plugin_connection_data(MYSQLND *conn, zend_bool handler_only TSRMLS_DC);

MYSQLND_UH_CONN_PLUGIN** mysqlnd_uh_get_plugin_connection_data_data(const MYSQLND_CONN_DATA *conn, zend_bool init_resource TSRMLS_DC);
void mysqlnd_uh_free_plugin_connection_data_data(MYSQLND_CONN_DATA *conn, zend_bool handler_only TSRMLS_DC);

/* data which we will associate with a mysqlnd statement */
typedef struct st_mysqlnd_uh_stmt_data {
	zval* user_obj;
	zval* user_resource;
} MYSQLND_UH_STMT_DATA;

MYSQLND_UH_STMT_DATA** mysqlnd_uh_get_plugin_statement_data(const MYSQLND_STMT *stmt, zend_bool init_resource TSRMLS_DC);
void mysqlnd_uh_conn_free_plugin_statement_data(MYSQLND_STMT *stmt, zend_bool handler_only TSRMLS_DC);

/* data which we will associate with a mysqlnd result */
typedef struct st_mysqlnd_uh_res_data {
	zval* user_obj;
	zval* user_resource;
} MYSQLND_UH_RESULT_DATA;

MYSQLND_UH_RESULT_DATA** mysqlnd_uh_get_plugin_result_data(const MYSQLND_RES *res, zend_bool init_resource TSRMLS_DC);
void mysqlnd_uh_conn_free_plugin_result_data(MYSQLND_RES *res, zend_bool handler_only TSRMLS_DC);

/* mysqlnd connection user resource */
typedef struct st_mysqlnd_uh_res_conn {
	MYSQLND* mysqlnd_conn;
	MYSQLND_CONN_DATA* mysqlnd_conn_data;
	zval* user_conn;
	zend_bool persistent;
	zval * user_resource;
} MYSQLND_UH_RES_CONN;

void mysqlnd_uh_minit_register_hooks_connection(TSRMLS_D);
void mysqlnd_uh_minit_register_hooks_connection_data(TSRMLS_D);
void mysqlnd_uh_minit_register_hooks_statement(TSRMLS_D);
void mysqlnd_uh_minit_register_hooks_result(TSRMLS_D);

#define MYSQLND_UH_MAKE_ZVAL(zv) \
	(zv) = (zval *) emalloc(sizeof(zval)); \
	INIT_PZVAL(zv)

#define MYSQLND_UH_DESTROY_ZVAL(zv) \
	efree(zv)

#define MYSQLND_UH_HOOK_ARG_STRING_LEN(name, len) \
	zval *zv_##name; \
	MAKE_STD_ZVAL(zv_##name); \
	ZVAL_STRINGL(zv_##name, name, (len), 1)

#define MYSQLND_UH_HOOK_ARG_STRING(name) \
	MYSQLND_UH_HOOK_ARG_STRING_LEN(name, ((name) ? strlen((name)) : 0))

#define MYSQLND_UH_HOOK_ARG_LONG(name) \
	zval *zv_##name; \
	MAKE_STD_ZVAL(zv_##name); \
	ZVAL_LONG(zv_##name, (long)(name))

#define MYSQLND_UH_HOOK_ARG_BOOL(name) \
	zval *zv_##name; \
	MAKE_STD_ZVAL(zv_##name); \
	ZVAL_BOOL(zv_##name, (name))

#define MYSQLND_UH_HOOK_ARG_NULL(name) \
	zval *zv_##name; \
	MAKE_STD_ZVAL(zv_##name); \
	ZVAL_NULL(zv_##name)

#define MYSQLND_UH_HOOK_ARG_RESOURCE(resource, plugin_data_ptr_ptr) \
	zval *resource; \
	if (*plugin_data_ptr_ptr) { \
		resource = (*plugin_data_ptr_ptr)->user_resource; \
	} else { \
		ZVAL_NULL(resource); \
	}

#define MYSQLND_UH_HOOK_RETVAL_CHECK_TYPE(retval, method_name, expect_type, type_name, class_name) \
	if (retval && MYSQLND_UH_G(report_wrong_types) && (Z_TYPE_P(retval) != expect_type)) { \
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " The method " class_name "::" method_name "() did not return a " type_name " value as it should"); \
	}

#define MYSQLND_UH_HOOK_RETVAL_BOOL_CHECK_TYPE(retval, method_name, class_name) \
		RETVAL_CHECK_TYPE(retval, method_name, IS_BOOL, "boolean", class_name)

#define MYSQLND_UH_HOOK_RETVAL_STRING_CHECK_TYPE(retval, method_name, class_name) \
		RETVAL_CHECK_TYPE(retval, method_name, IS_STRING, "string", class_name)

#define MYSQLND_UH_HOOK_RETVAL_NUMBER_CHECK_TYPE(retval, method_name, type_name, class_name, has_wrong_type) \
	if (retval && (Z_TYPE_P(retval) != IS_LONG)) { \
		has_wrong_type = 1; \
		if (MYSQLND_UH_G(report_wrong_types)) \
			php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " The method " class_name "::" method_name "() did not return a numeric value as it should (C type used by mysqlnd: " #type_name "). Setting return value to 0"); \
	} else { \
		has_wrong_type = 0; \
	}

#define MYSQLND_UH_HOOK_RETVAL_BOOL_TO_FUNC_STATUS(retval, ret) \
	if (retval) { \
		ret = (Z_BVAL_P(retval)) ? PASS : FAIL; \
		zval_ptr_dtor(&retval); \
	}

#define MYSQLND_UH_HOOK_RETVAL_INTERNAL_RESOURCE(retval, resource, resource_type, resource_name, le_resource, bail_if_no_resource, class_name) \
	if (retval) { \
		if (Z_TYPE_P(retval) == IS_RESOURCE) { \
			ZEND_FETCH_RESOURCE_NO_RETURN(resource, resource_type, &retval, -1, (bail_if_no_resource) ? resource_name : NULL, le_resource); \
			if (resource) { \
				zend_hash_index_del(&EG(regular_list), Z_RESVAL_P(retval)); \
			} \
		} \
		zval_ptr_dtor(&retval); \
	} else { \
		resource = NULL; \
	} \
	if (bail_if_no_resource && !resource) \
		php_error_docref(NULL TSRMLS_CC, E_WARNING, MYSQLND_UH_ERROR_PREFIX " You either have not called the appropriate method from the " \
			class_name \
			" class or you are not returning the return value you got from it. Wrong results, errors and even crashes may happen!");

#define MYSQLND_UH_HOOK_METHOD_ONE_ARG_RES_RET_FUNC_STATUS(org_methods, mysqlnd_class, mysqlnd_method_name, userland_method_name, userland_method_name_cc, mysqlnd_obj, mysqlnd_obj_arg_decl) \
	enum_func_status MYSQLND_METHOD(mysqlnd_class, mysqlnd_method_name)(mysqlnd_obj_arg_decl TSRMLS_DC) { \
		enum_func_status ret = FAIL; \
		DBG_ENTER(#mysqlnd_class "." #mysqlnd_method_name); \
		DBG_INF_FMT("mysqlnd object %p", mysqlnd_obj); \
		\
		EXTRACT_DATA_AND_USER_OBJ(mysqlnd_obj, plugin_data, user_hook_obj); \
		if (user_hook_obj) { \
			MYSQLND_UH_HOOK_ARG_RESOURCE(resource, plugin_data); \
			zval *retval = NULL; \
			mysqlnd_uh_call_method_with_1_params(user_hook_obj, NULL, #userland_method_name, &retval, resource); \
			RETVAL_BOOL_CHECK_TYPE(retval, #userland_method_name_cc); \
			RETVAL_BOOL_TO_FUNC_STATUS(retval, ret); \
		} else { \
			ret = org_methods.mysqlnd_method_name(mysqlnd_obj TSRMLS_CC); \
		} \
		\
		DBG_RETURN(ret); \
	}

#endif	/* MYSQLND_UH_HOOKS_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
